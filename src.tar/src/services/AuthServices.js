import { jwtDecode } from "jwt-decode";
import api from "./api.js";
import { ENDPOINTS } from "../config.js";

class AuthService {
  async login(username, password) {
    try {
      console.log("Logging in with username:", username);
      const response = await api.post(ENDPOINTS.LOGIN, { 
        username, 
        password 
      });
      
      if (response.data.token) {
        const userData = {
          token: response.data.token,
          user: response.data.user || response.data,
          role: response.data.role || response.data.user?.role
        };
        localStorage.setItem("user", JSON.stringify(userData));
        console.log("Login successful:", userData);
        console.log("Token stored:", response.data.token.substring(0, 50) + '...');
        return { success: true, data: userData };
      }
      
      return { success: false, message: "No token received" };
    } catch (error) {
      console.error("Login error:", error);
      const message = error.response?.data?.message || "Login failed";
      return { success: false, message };
    }
  }

  logout() {
    localStorage.removeItem("user");
  }

  getCurrentUser() {
    const stored = localStorage.getItem("user");
    if (!stored) return null;

    try {
      const userData = JSON.parse(stored);
      if (userData.token) {
        const decoded = jwtDecode(userData.token);
        return {
          ...decoded,
          name: decoded.name || decoded.nameid || decoded.sub || userData.user?.name,
          email: decoded.email || userData.user?.email,
          role: decoded.role || userData.role || userData.user?.role
        };
      }
      return userData.user || userData;
    } catch (err) {
      console.error("Error decoding token:", err);
      return null;
    }
  }

  isTokenExpired(token) {
    try {
      const decoded = jwtDecode(token);
      return decoded.exp * 1000 < Date.now();
    } catch {
      return true;
    }
  }

  getUserRole() {
    const user = this.getCurrentUser();
    return user?.role || null;
  }

  isLoggedIn() {
    const stored = localStorage.getItem("user");
    if (!stored) return false;

    try {
      const { token } = JSON.parse(stored);
      return token && !this.isTokenExpired(token);
    } catch {
      return false;
    }
  }

  getToken() {
    const stored = localStorage.getItem("user");
    if (!stored) return null;

    try {
      const { token } = JSON.parse(stored);
      return token;
    } catch {
      return null;
    }
  }

  // Method to manually set token for testing
  setToken(token) {
    const userData = {
      token: token,
      user: null,
      role: null
    };
    localStorage.setItem("user", JSON.stringify(userData));
    console.log("Token manually set:", token.substring(0, 50) + '...');
  }

  // Method to refresh token
  async refreshToken() {
    try {
      const response = await api.post(ENDPOINTS.REFRESH_TOKEN);
      if (response.data.token) {
        const userData = {
          token: response.data.token,
          user: response.data.user || response.data,
          role: response.data.role || response.data.user?.role
        };
        localStorage.setItem("user", JSON.stringify(userData));
        console.log("Token refreshed successfully");
        return { success: true, data: userData };
      }
      return { success: false, message: "No token received" };
    } catch (error) {
      console.error("Token refresh error:", error);
      return { success: false, message: "Token refresh failed" };
    }
  }

  // Method to check if token needs refresh
  shouldRefreshToken() {
    const token = this.getToken();
    if (!token) return false;
    
    try {
      const decoded = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      const timeUntilExpiry = decoded.exp - currentTime;
      // Refresh if token expires in less than 5 minutes
      return timeUntilExpiry < 300;
    } catch {
      return true;
    }
  }
}

// ✅ Export a singleton instance
export default new AuthService();
