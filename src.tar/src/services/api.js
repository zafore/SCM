import axios from "axios";
import { API_BASE_URL } from "../config.js";

// Create axios instance with base configuration
const instance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add authorization token
instance.interceptors.request.use(
  async (config) => {
    // Get token from localStorage (stored by AuthService)
    const userData = localStorage.getItem('user');
    if (userData) {
      try {
        const parsedUserData = JSON.parse(userData);
        const token = parsedUserData.token;
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
          console.log('Adding Authorization header with token:', token.substring(0, 20) + '...');
        } else {
          console.log('No token found in user data');
        }
      } catch (error) {
        console.error('Error parsing user data from localStorage:', error);
      }
    } else {
      console.log('No user data found in localStorage');
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle common errors
instance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('API Error:', {
      status: error.response?.status,
      statusText: error.response?.statusText,
      url: error.config?.url,
      method: error.config?.method,
      data: error.response?.data
    });

    // Handle 401 Unauthorized errors - but be more selective
    if (error.response?.status === 401) {
      // Only logout for authentication-related endpoints
      const authEndpoints = ['/identity/login', '/identity/register', '/admin/users'];
      const isAuthEndpoint = authEndpoints.some(endpoint => 
        error.config?.url?.includes(endpoint)
      );
      
      if (isAuthEndpoint) {
        console.log('Authentication endpoint 401 error - logging out');
        localStorage.removeItem('user');
        window.location.href = '/login';
      } else {
        console.log('Non-auth endpoint 401 error - not logging out');
      }
      // For other endpoints, just reject the promise without logging out
    }
    return Promise.reject(error);
  }
);

export default instance;
