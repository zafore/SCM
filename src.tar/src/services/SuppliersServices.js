import api from './api.js';
import { ENDPOINTS } from '../config.js';

class SuppliersService {
  // Get all suppliers with optional filtering and pagination
  async getSuppliers(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page) queryParams.append('page', params.page);
      if (params.pageSize) queryParams.append('pageSize', params.pageSize);
      if (params.search) queryParams.append('search', params.search);
      if (params.status && params.status !== 'all') queryParams.append('status', params.status);
      if (params.country && params.country !== 'all') queryParams.append('country', params.country);
      if (params.category) queryParams.append('category', params.category);
      if (params.sortBy) queryParams.append('sortBy', params.sortBy);
      if (params.sortOrder) queryParams.append('sortOrder', params.sortOrder);

      const url = queryParams.toString() ? `${ENDPOINTS.SUPPLIERS}?${queryParams}` : ENDPOINTS.SUPPLIERS;
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      console.error('Error fetching suppliers:', error);
      throw error;
    }
  }

  // Get supplier by ID
  async getSupplierById(id) {
    try {
      const response = await api.get(`${ENDPOINTS.SUPPLIERS}/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching supplier ${id}:`, error);
      throw error;
    }
  }

  // Create new supplier
  async createSupplier(supplierData) {
    try {
      const response = await api.post(ENDPOINTS.SUPPLIERS, supplierData);
      return response.data;
    } catch (error) {
      console.error('Error creating supplier:', error);
      throw error;
    }
  }

  // Update existing supplier
  async updateSupplier(id, supplierData) {
    try {
      const response = await api.put(`${ENDPOINTS.SUPPLIERS}/${id}`, supplierData);
      return response.data;
    } catch (error) {
      console.error(`Error updating supplier ${id}:`, error);
      throw error;
    }
  }

  // Delete supplier
  async deleteSupplier(id) {
    try {
      const response = await api.delete(`${ENDPOINTS.SUPPLIERS}/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error deleting supplier ${id}:`, error);
      throw error;
    }
  }

  // Get supplier statistics
  async getSupplierStats() {
    try {
      const response = await api.get(ENDPOINTS.SUPPLIER_STATS);
      return response.data;
    } catch (error) {
      console.error('Error fetching supplier stats:', error);
      throw error;
    }
  }

  // Get supplier performance metrics
  async getSupplierPerformance(id, period = '30d') {
    try {
      const response = await api.get(`${ENDPOINTS.SUPPLIERS}/${id}/performance?period=${period}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching supplier performance ${id}:`, error);
      throw error;
    }
  }

  // Get supplier contracts
  async getSupplierContracts(id) {
    try {
      const response = await api.get(`${ENDPOINTS.SUPPLIERS}/${id}/contracts`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching supplier contracts ${id}:`, error);
      throw error;
    }
  }

  // Get supplier orders
  async getSupplierOrders(id, params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page) queryParams.append('page', params.page);
      if (params.pageSize) queryParams.append('pageSize', params.pageSize);
      if (params.status) queryParams.append('status', params.status);
      if (params.startDate) queryParams.append('startDate', params.startDate);
      if (params.endDate) queryParams.append('endDate', params.endDate);

      const url = queryParams.toString() ? `${ENDPOINTS.SUPPLIERS}/${id}/orders?${queryParams}` : `${ENDPOINTS.SUPPLIERS}/${id}/orders`;
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      console.error(`Error fetching supplier orders ${id}:`, error);
      throw error;
    }
  }

  // Export suppliers to CSV
  async exportSuppliers(params = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.status && params.status !== 'all') queryParams.append('status', params.status);
      if (params.country && params.country !== 'all') queryParams.append('country', params.country);
      if (params.category) queryParams.append('category', params.category);
      if (params.format) queryParams.append('format', params.format || 'csv');

      const url = queryParams.toString() ? `${ENDPOINTS.SUPPLIERS}/export?${queryParams}` : `${ENDPOINTS.SUPPLIERS}/export`;
      const response = await api.get(url, {
        responseType: 'blob'
      });
      
      // Create download link
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url2 = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url2;
      a.download = `suppliers_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url2);
      document.body.removeChild(a);
      
      return true;
    } catch (error) {
      console.error('Error exporting suppliers:', error);
      throw error;
    }
  }

  // Bulk operations
  async bulkUpdateSuppliers(supplierIds, updateData) {
    try {
      const response = await api.put(`${ENDPOINTS.SUPPLIERS}/bulk`, {
        supplierIds,
        updateData
      });
      return response.data;
    } catch (error) {
      console.error('Error bulk updating suppliers:', error);
      throw error;
    }
  }

  async bulkDeleteSuppliers(supplierIds) {
    try {
      const response = await api.delete(`${ENDPOINTS.SUPPLIERS}/bulk`, {
        data: { supplierIds }
      });
      return response.data;
    } catch (error) {
      console.error('Error bulk deleting suppliers:', error);
      throw error;
    }
  }

  // Search and filter utilities
  async searchSuppliers(query, filters = {}) {
    try {
      const searchParams = {
        search: query,
        ...filters
      };
      return await this.getSuppliers(searchParams);
    } catch (error) {
      console.error('Error searching suppliers:', error);
      throw error;
    }
  }

  // Get supplier categories
  async getSupplierCategories() {
    try {
      const response = await api.get(`${ENDPOINTS.SUPPLIERS}/categories`);
      return response.data;
    } catch (error) {
      console.error('Error fetching supplier categories:', error);
      throw error;
    }
  }

  // Get supplier countries
  async getSupplierCountries() {
    try {
      const response = await api.get(`${ENDPOINTS.SUPPLIERS}/countries`);
      return response.data;
    } catch (error) {
      console.error('Error fetching supplier countries:', error);
      throw error;
    }
  }
}

export default new SuppliersService();
