// Response Handler Utility
export class ResponseHandler {
  /**
   * Standardize API response format
   * @param {Object} response - Axios response object
   * @returns {Object} Standardized response
   */
  static standardizeResponse(response) {
    if (!response) {
      return { success: false, data: null, message: 'No response received', status: 0 };
    }

    const { data, status } = response;
    
    // Fast path for common cases
    if (Array.isArray(data)) {
      return { success: true, data, status, totalCount: data.length };
    }

    if (data && typeof data === 'object') {
      // Paginated response
      if (data.items && Array.isArray(data.items)) {
        return {
          success: true,
          data: data.items,
          status,
          totalCount: data.totalCount || data.items.length,
          page: data.page,
          pageSize: data.pageSize,
          totalPages: data.totalPages
        };
      }

      // Nested response
      if (data.data) {
        return { success: true, data: data.data, status };
      }

      // Direct object
      return { success: true, data, status };
    }

    return { success: true, data, status };
  }

  /**
   * Handle API errors consistently
   * @param {Object} error - Error object
   * @returns {Object} Standardized error response
   */
  static handleError(error) {
    // Only log in development mode
    if (import.meta.env.DEV) {
      console.error('API Error:', error);
    }

    let errorResponse = {
      success: false,
      data: null,
      message: 'An unexpected error occurred',
      status: 0,
      error: error
    };

    if (error.response) {
      // Server responded with error status
      const { status, data, statusText } = error.response;
      
      errorResponse.status = status;
      errorResponse.message = data?.message || data?.error || statusText || 'Server error';
      errorResponse.data = data;

      // Handle specific status codes
      switch (status) {
        case 400:
          errorResponse.message = 'Bad request. Please check your input.';
          break;
        case 401:
          errorResponse.message = 'Authentication required. Please log in.';
          break;
        case 403:
          errorResponse.message = 'Access denied. You do not have permission.';
          break;
        case 404:
          errorResponse.message = 'API endpoint not found. Backend service may not be running.';
          break;
        case 422:
          errorResponse.message = 'Validation error. Please check your input.';
          break;
        case 500:
          errorResponse.message = 'Internal server error. Please try again later.';
          break;
        default:
          errorResponse.message = data?.message || statusText || 'Server error';
      }
    } else if (error.request) {
      // Request was made but no response received
      errorResponse.message = 'No response from server. Please check your connection or backend service.';
      errorResponse.status = 0;
    } else if (error.code === 'ERR_NETWORK') {
      // Network error - backend not running
      errorResponse.message = 'Network error. Backend service is not running. Using mock data for demonstration.';
      errorResponse.status = 0;
      errorResponse.isNetworkError = true;
    } else {
      // Something else happened
      errorResponse.message = error.message || 'Network error occurred';
      errorResponse.status = 0;
    }

    return errorResponse;
  }

  /**
   * Validate response data structure
   * @param {Object} data - Response data
   * @param {Array} requiredFields - Required fields to check
   * @returns {Object} Validation result
   */
  static validateData(data, requiredFields = []) {
    if (!data) {
      return {
        isValid: false,
        message: 'No data provided'
      };
    }

    if (Array.isArray(data)) {
      return {
        isValid: true,
        message: 'Array data is valid'
      };
    }

    if (typeof data !== 'object') {
      return {
        isValid: false,
        message: 'Data is not an object'
      };
    }

    const missingFields = requiredFields.filter(field => !(field in data));
    
    if (missingFields.length > 0) {
      return {
        isValid: false,
        message: `Missing required fields: ${missingFields.join(', ')}`
      };
    }

    return {
      isValid: true,
      message: 'Data validation passed'
    };
  }

  /**
   * Transform response data for consistent format
   * @param {Object} data - Raw response data
   * @param {Function} transformer - Transformation function
   * @returns {Object} Transformed data
   */
  static transformData(data, transformer) {
    if (!data) return null;
    
    if (Array.isArray(data)) {
      return data.map(item => transformer ? transformer(item) : item);
    }
    
    return transformer ? transformer(data) : data;
  }

  /**
   * Extract pagination info from response
   * @param {Object} response - API response
   * @returns {Object} Pagination info
   */
  static extractPagination(response) {
    if (!response || !response.data) {
      return {
        page: 1,
        pageSize: 10,
        totalCount: 0,
        totalPages: 0
      };
    }

    const { data } = response;
    
    return {
      page: data.page || 1,
      pageSize: data.pageSize || 10,
      totalCount: data.totalCount || (Array.isArray(data.items) ? data.items.length : 0),
      totalPages: data.totalPages || Math.ceil((data.totalCount || 0) / (data.pageSize || 10))
    };
  }
}
