import { BaseService } from './base.service.js';
import { API_ENDPOINTS } from '../config/endpoints.js';

// Supplier Service Class
export class SupplierService extends BaseService {
  constructor() {
    super();
  }

  /**
   * Get all suppliers with optional filtering and pagination
   * @param {Object} params - Query parameters
   * @returns {Promise} Suppliers data
   */
  async getSuppliers(params = {}) {
    const url = this.buildUrl(API_ENDPOINTS.SUPPLIERS.BASE, params);
    return await this.get(url);
  }

  /**
   * Get supplier by ID
   * @param {string|number} id - Supplier ID
   * @returns {Promise} Supplier data
   */
  async getSupplierById(id) {
    const url = API_ENDPOINTS.SUPPLIERS.BY_ID(id);
    return await this.get(url);
  }

  /**
   * Create new supplier
   * @param {Object} supplierData - Supplier data
   * @returns {Promise} Created supplier
   */
  async createSupplier(supplierData) {
    return await this.post(API_ENDPOINTS.SUPPLIERS.BASE, supplierData);
  }

  /**
   * Update existing supplier
   * @param {string|number} id - Supplier ID
   * @param {Object} supplierData - Updated supplier data
   * @returns {Promise} Updated supplier
   */
  async updateSupplier(id, supplierData) {
    const url = API_ENDPOINTS.SUPPLIERS.BY_ID(id);
    return await this.put(url, supplierData);
  }

  /**
   * Delete supplier
   * @param {string|number} id - Supplier ID
   * @returns {Promise} Deletion result
   */
  async deleteSupplier(id) {
    const url = API_ENDPOINTS.SUPPLIERS.BY_ID(id);
    return await this.delete(url);
  }

  /**
   * Get supplier statistics
   * @returns {Promise} Supplier statistics
   */
  async getSupplierStats() {
    return await this.get(API_ENDPOINTS.SUPPLIERS.STATS);
  }

  /**
   * Get supplier performance metrics
   * @param {string|number} id - Supplier ID
   * @param {string} period - Time period (30d, 90d, 1y)
   * @returns {Promise} Performance data
   */
  async getSupplierPerformance(id, period = '30d') {
    const url = API_ENDPOINTS.SUPPLIERS.PERFORMANCE(id, period);
    return await this.get(url);
  }

  /**
   * Get supplier contracts
   * @param {string|number} id - Supplier ID
   * @returns {Promise} Contracts data
   */
  async getSupplierContracts(id) {
    const url = API_ENDPOINTS.SUPPLIERS.CONTRACTS(id);
    return await this.get(url);
  }

  /**
   * Get supplier orders
   * @param {string|number} id - Supplier ID
   * @param {Object} params - Query parameters
   * @returns {Promise} Orders data
   */
  async getSupplierOrders(id, params = {}) {
    const url = this.buildUrl(API_ENDPOINTS.SUPPLIERS.ORDERS(id), params);
    return await this.get(url);
  }

  /**
   * Export suppliers to CSV
   * @param {Object} params - Export parameters
   * @returns {Promise} Export result
   */
  async exportSuppliers(params = {}) {
    const url = this.buildUrl(API_ENDPOINTS.SUPPLIERS.EXPORT, params);
    const filename = `suppliers_${new Date().toISOString().split('T')[0]}.csv`;
    return await this.download(url, {}, filename);
  }

  /**
   * Bulk update suppliers
   * @param {Array} supplierIds - Array of supplier IDs
   * @param {Object} updateData - Data to update
   * @returns {Promise} Bulk update result
   */
  async bulkUpdateSuppliers(supplierIds, updateData) {
    return await this.put(API_ENDPOINTS.SUPPLIERS.BULK, {
      supplierIds,
      updateData
    });
  }

  /**
   * Bulk delete suppliers
   * @param {Array} supplierIds - Array of supplier IDs
   * @returns {Promise} Bulk delete result
   */
  async bulkDeleteSuppliers(supplierIds) {
    return await this.delete(API_ENDPOINTS.SUPPLIERS.BULK, {
      data: { supplierIds }
    });
  }

  /**
   * Search suppliers
   * @param {string} query - Search query
   * @param {Object} filters - Additional filters
   * @returns {Promise} Search results
   */
  async searchSuppliers(query, filters = {}) {
    const params = {
      search: query,
      ...filters
    };
    return await this.getSuppliers(params);
  }

  /**
   * Get supplier categories
   * @returns {Promise} Categories data
   */
  async getSupplierCategories() {
    return await this.get(API_ENDPOINTS.SUPPLIERS.CATEGORIES);
  }

  /**
   * Get supplier countries
   * @returns {Promise} Countries data
   */
  async getSupplierCountries() {
    return await this.get(API_ENDPOINTS.SUPPLIERS.COUNTRIES);
  }

  /**
   * Validate supplier data
   * @param {Object} supplierData - Supplier data to validate
   * @returns {Object} Validation result
   */
  validateSupplierData(supplierData) {
    const requiredFields = [
      'supplierName',
      'email',
      'contactPerson',
      'city',
      'country'
    ];

    const validation = {
      isValid: true,
      errors: []
    };

    // Check required fields
    requiredFields.forEach(field => {
      if (!supplierData[field] || supplierData[field].trim() === '') {
        validation.isValid = false;
        validation.errors.push(`${field} is required`);
      }
    });

    // Validate email format
    if (supplierData.email && !this.isValidEmail(supplierData.email)) {
      validation.isValid = false;
      validation.errors.push('Invalid email format');
    }

    // Validate phone format (if provided)
    if (supplierData.phone && !this.isValidPhone(supplierData.phone)) {
      validation.isValid = false;
      validation.errors.push('Invalid phone format');
    }

    return validation;
  }

  /**
   * Validate email format
   * @param {string} email - Email to validate
   * @returns {boolean} Is valid email
   */
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Validate phone format
   * @param {string} phone - Phone to validate
   * @returns {boolean} Is valid phone
   */
  isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
  }

  /**
   * Transform supplier data for API
   * @param {Object} supplierData - Raw supplier data
   * @returns {Object} Transformed data
   */
  transformSupplierData(supplierData) {
    return {
      ...supplierData,
      // Ensure consistent field names
      supplierName: supplierData.supplierName || supplierData.name,
      contactPerson: supplierData.contactPerson || supplierData.contact,
      // Format dates
      contractExpiry: supplierData.contractExpiry ? new Date(supplierData.contractExpiry).toISOString() : null,
      // Ensure numeric fields
      rating: parseFloat(supplierData.rating) || 0,
      totalSpent: parseFloat(supplierData.totalSpent) || 0,
      totalOrders: parseInt(supplierData.totalOrders) || 0
    };
  }
}

// Export singleton instance
export default new SupplierService();
