import { BaseService } from './base.service.js';
import { API_ENDPOINTS } from '../config/endpoints.js';
import { jwtDecode } from 'jwt-decode';

// Auth Service Class
export class AuthService extends BaseService {
  constructor() {
    super();
  }

  /**
   * Login user
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {Promise} Login result
   */
  async login(username, password) {
    try {
      // Demo mode - check for demo credentials
      if (this.isDemoMode(username, password)) {
        return this.handleDemoLogin(username, password);
      }

      const response = await this.post(API_ENDPOINTS.AUTH.LOGIN, {
        username,
        password
      });

      if (response.success && response.data?.token) {
        const userData = {
          token: response.data.token,
          user: response.data.user || response.data,
          role: response.data.role || response.data.user?.role
        };
        
        localStorage.setItem('user', JSON.stringify(userData));
        console.log('🔐 Login successful:', userData);
        console.log('🔑 Token stored:', response.data.token.substring(0, 50) + '...');
        
        return { success: true, data: userData };
      }
      
      return { success: false, message: response.message || 'No token received' };
    } catch (error) {
      // If network error, try demo mode as fallback
      if (error.code === 'ERR_NETWORK' || error.response?.status === 404) {
        console.log('Backend not available, trying demo mode');
        return this.handleDemoLogin(username, password);
      }
      
      console.error('❌ Login error:', error);
      return { success: false, message: error.message || 'Login failed' };
    }
  }

  /**
   * Register new user
   * @param {Object} userData - User registration data
   * @returns {Promise} Registration result
   */
  async register(userData) {
    return await this.post(API_ENDPOINTS.AUTH.REGISTER, userData);
  }

  /**
   * Logout user
   * @returns {Promise} Logout result
   */
  async logout() {
    try {
      // Call logout endpoint if available
      await this.post(API_ENDPOINTS.AUTH.LOGOUT);
    } catch (error) {
      console.warn('Logout endpoint not available, clearing local storage only');
    } finally {
      // Always clear local storage
      localStorage.removeItem('user');
      console.log('🔓 Logout completed');
    }
    
    return { success: true, message: 'Logged out successfully' };
  }

  /**
   * Refresh authentication token
   * @returns {Promise} Token refresh result
   */
  async refreshToken() {
    try {
      const response = await this.post(API_ENDPOINTS.AUTH.REFRESH_TOKEN);
      
      if (response.success && response.data?.token) {
        const userData = {
          token: response.data.token,
          user: response.data.user || response.data,
          role: response.data.role || response.data.user?.role
        };
        
        localStorage.setItem('user', JSON.stringify(userData));
        console.log('🔄 Token refreshed successfully');
        
        return { success: true, data: userData };
      }
      
      return { success: false, message: response.message || 'No token received' };
    } catch (error) {
      console.error('❌ Token refresh error:', error);
      return { success: false, message: 'Token refresh failed' };
    }
  }

  /**
   * Verify token validity
   * @returns {Promise} Token verification result
   */
  async verifyToken() {
    try {
      const response = await this.get(API_ENDPOINTS.AUTH.VERIFY_TOKEN);
      return { success: true, data: response.data };
    } catch (error) {
      console.error('❌ Token verification error:', error);
      return { success: false, message: 'Token verification failed' };
    }
  }

  /**
   * Get current user from token
   * @returns {Object|null} Current user data
   */
  getCurrentUser() {
    const stored = localStorage.getItem('user');
    if (!stored) return null;

    try {
      const userData = JSON.parse(stored);
      if (userData.token) {
        const decoded = jwtDecode(userData.token);
        return {
          ...decoded,
          name: decoded.name || decoded.nameid || decoded.sub || userData.user?.name,
          email: decoded.email || userData.user?.email,
          role: decoded.role || userData.role || userData.user?.role
        };
      }
      return userData.user || userData;
    } catch (err) {
      console.error('❌ Error decoding token:', err);
      return null;
    }
  }

  /**
   * Check if token is expired
   * @param {string} token - JWT token
   * @returns {boolean} Is token expired
   */
  isTokenExpired(token) {
    try {
      const decoded = jwtDecode(token);
      return decoded.exp * 1000 < Date.now();
    } catch {
      return true;
    }
  }

  /**
   * Get user role
   * @returns {string|null} User role
   */
  getUserRole() {
    const user = this.getCurrentUser();
    return user?.role || null;
  }

  /**
   * Check if user is logged in
   * @returns {boolean} Is logged in
   */
  isLoggedIn() {
    const stored = localStorage.getItem('user');
    if (!stored) return false;

    try {
      const { token } = JSON.parse(stored);
      return token && !this.isTokenExpired(token);
    } catch {
      return false;
    }
  }

  /**
   * Get authentication token
   * @returns {string|null} Authentication token
   */
  getToken() {
    const stored = localStorage.getItem('user');
    if (!stored) return null;

    try {
      const { token } = JSON.parse(stored);
      return token;
    } catch {
      return null;
    }
  }

  /**
   * Check if token needs refresh
   * @returns {boolean} Should refresh token
   */
  shouldRefreshToken() {
    const token = this.getToken();
    if (!token) return false;
    
    try {
      const decoded = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      const timeUntilExpiry = decoded.exp - currentTime;
      // Refresh if token expires in less than 5 minutes
      return timeUntilExpiry < 300;
    } catch {
      return true;
    }
  }

  /**
   * Manually set token (for testing)
   * @param {string} token - JWT token
   */
  setToken(token) {
    const userData = {
      token: token,
      user: null,
      role: null
    };
    localStorage.setItem('user', JSON.stringify(userData));
    console.log('🔧 Token manually set:', token.substring(0, 50) + '...');
  }

  /**
   * Clear authentication data
   */
  clearAuth() {
    localStorage.removeItem('user');
    console.log('🧹 Authentication data cleared');
  }

  /**
   * Validate user credentials
   * @param {Object} credentials - User credentials
   * @returns {Object} Validation result
   */
  validateCredentials(credentials) {
    const validation = {
      isValid: true,
      errors: []
    };

    if (!credentials.username || credentials.username.trim() === '') {
      validation.isValid = false;
      validation.errors.push('Username is required');
    }

    if (!credentials.password || credentials.password.trim() === '') {
      validation.isValid = false;
      validation.errors.push('Password is required');
    }

    if (credentials.password && credentials.password.length < 6) {
      validation.isValid = false;
      validation.errors.push('Password must be at least 6 characters');
    }

    return validation;
  }

  /**
   * Check user permissions
   * @param {string} permission - Permission to check
   * @returns {boolean} Has permission
   */
  hasPermission(permission) {
    const user = this.getCurrentUser();
    if (!user) return false;

    // Check role-based permissions
    const rolePermissions = {
      'Admin': ['read', 'write', 'delete', 'manage_users', 'manage_suppliers'],
      'Manager': ['read', 'write', 'manage_suppliers'],
      'User': ['read']
    };

    const userRole = user.role || 'User';
    const permissions = rolePermissions[userRole] || [];
    
    return permissions.includes(permission);
  }

  /**
   * Check if user has any of the specified roles
   * @param {Array} roles - Roles to check
   * @returns {boolean} Has any role
   */
  hasAnyRole(roles) {
    const userRole = this.getUserRole();
    return roles.includes(userRole);
  }

  /**
   * Check if credentials are for demo mode
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {boolean} Is demo mode
   */
  isDemoMode(username, password) {
    const demoCredentials = [
      { username: 'admin@test.com', password: 'Admin123!' },
      { username: 'admin', password: 'admin' },
      { username: 'demo', password: 'demo' },
      { username: 'test', password: 'test' }
    ];
    
    return demoCredentials.some(cred => 
      cred.username === username && cred.password === password
    );
  }

  /**
   * Handle demo login
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {Object} Demo login result
   */
  handleDemoLogin(username, password) {
    // Create a demo JWT token
    const demoToken = this.generateDemoToken(username);
    
    const userData = {
      token: demoToken,
      user: {
        id: 1,
        username: username,
        email: username,
        name: username === 'admin@test.com' ? 'Admin User' : 'Demo User',
        role: username === 'admin@test.com' ? 'Admin' : 'User'
      },
      role: username === 'admin@test.com' ? 'Admin' : 'User'
    };
    
    localStorage.setItem('user', JSON.stringify(userData));
    console.log('🔐 Demo login successful:', userData);
    
    return { 
      success: true, 
      data: userData,
      message: 'Demo login successful (Backend not available)'
    };
  }

  /**
   * Generate a demo JWT token
   * @param {string} username - Username
   * @returns {string} Demo token
   */
  generateDemoToken(username) {
    const payload = {
      sub: username,
      name: username === 'admin@test.com' ? 'Admin User' : 'Demo User',
      email: username,
      role: username === 'admin@test.com' ? 'Admin' : 'User',
      exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60), // 24 hours
      iat: Math.floor(Date.now() / 1000)
    };
    
    // Simple base64 encoding for demo (not secure, just for demo)
    return btoa(JSON.stringify(payload));
  }
}

// Export singleton instance
export default new AuthService();
