import axios from 'axios';
import { API_CONFIG } from '../config/endpoints.js';
import { setupRequestInterceptor, setupResponseInterceptor, retryRequest } from '../config/interceptors.js';
import { ResponseHandler } from '../utils/response.handler.js';
import ApiCache from '../utils/cache.js';

// Base API Service Class
export class BaseService {
  constructor() {
    this.api = axios.create({
      baseURL: API_CONFIG.BASE_URL,
      timeout: parseInt(API_CONFIG.TIMEOUT) || 10000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    // Setup interceptors
    setupRequestInterceptor(this.api);
    setupResponseInterceptor(this.api);
  }

  /**
   * Make a GET request
   * @param {string} url - API endpoint
   * @param {Object} params - Query parameters
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async get(url, params = {}, config = {}) {
    try {
      // Check cache first
      const cached = ApiCache.get(url, params);
      if (cached) {
        return cached;
      }

      const response = await this.api.get(url, {
        params,
        ...config
      });
      
      const result = ResponseHandler.standardizeResponse(response);
      
      // Cache successful responses
      if (result.success) {
        ApiCache.set(url, params, result);
      }
      
      return result;
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Make a POST request
   * @param {string} url - API endpoint
   * @param {Object} data - Request body
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async post(url, data = {}, config = {}) {
    try {
      const response = await this.api.post(url, data, config);
      return ResponseHandler.standardizeResponse(response);
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Make a PUT request
   * @param {string} url - API endpoint
   * @param {Object} data - Request body
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async put(url, data = {}, config = {}) {
    try {
      const response = await this.api.put(url, data, config);
      return ResponseHandler.standardizeResponse(response);
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Make a DELETE request
   * @param {string} url - API endpoint
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async delete(url, config = {}) {
    try {
      const response = await this.api.delete(url, config);
      return ResponseHandler.standardizeResponse(response);
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Make a PATCH request
   * @param {string} url - API endpoint
   * @param {Object} data - Request body
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async patch(url, data = {}, config = {}) {
    try {
      const response = await this.api.patch(url, data, config);
      return ResponseHandler.standardizeResponse(response);
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Upload file
   * @param {string} url - API endpoint
   * @param {FormData} formData - Form data with file
   * @param {Object} config - Additional axios config
   * @returns {Promise} Standardized response
   */
  async upload(url, formData, config = {}) {
    try {
      const response = await this.api.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        ...config
      });
      return ResponseHandler.standardizeResponse(response);
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Download file
   * @param {string} url - API endpoint
   * @param {Object} params - Query parameters
   * @param {string} filename - Filename for download
   * @returns {Promise} Download response
   */
  async download(url, params = {}, filename = 'download') {
    try {
      const response = await this.api.get(url, {
        params,
        responseType: 'blob'
      });

      // Create download link
      const blob = new Blob([response.data]);
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);

      return {
        success: true,
        message: 'File downloaded successfully'
      };
    } catch (error) {
      return ResponseHandler.handleError(error);
    }
  }

  /**
   * Build query string from parameters
   * @param {Object} params - Parameters object
   * @returns {string} Query string
   */
  buildQueryString(params) {
    const queryParams = new URLSearchParams();
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        if (Array.isArray(value)) {
          value.forEach(item => queryParams.append(key, item));
        } else {
          queryParams.append(key, value);
        }
      }
    });

    return queryParams.toString();
  }

  /**
   * Build URL with query parameters
   * @param {string} baseUrl - Base URL
   * @param {Object} params - Query parameters
   * @returns {string} Full URL with query string
   */
  buildUrl(baseUrl, params = {}) {
    const queryString = this.buildQueryString(params);
    return queryString ? `${baseUrl}?${queryString}` : baseUrl;
  }

  /**
   * Retry request with exponential backoff
   * @param {Function} requestFn - Request function to retry
   * @param {number} maxRetries - Maximum retry attempts
   * @returns {Promise} Request result
   */
  async retryRequest(requestFn, maxRetries = parseInt(API_CONFIG.RETRY_ATTEMPTS) || 3) {
    let lastError;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await requestFn();
      } catch (error) {
        lastError = error;
        
        if (attempt === maxRetries) {
          break;
        }

        // Wait before retrying (exponential backoff)
        const delay = (parseInt(API_CONFIG.RETRY_DELAY) || 1000) * Math.pow(2, attempt);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    
    return ResponseHandler.handleError(lastError);
  }
}
