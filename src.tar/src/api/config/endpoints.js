// API Endpoints Configuration
export const API_ENDPOINTS = {
  // Authentication
  AUTH: {
    LOGIN: '/identity/login',
    REGISTER: '/identity/register',
    REFRESH_TOKEN: '/identity/refresh-token',
    LOGOUT: '/identity/logout',
    VERIFY_TOKEN: '/identity/verify'
  },

  // Suppliers
  SUPPLIERS: {
    BASE: '/api/suppliers',
    BY_ID: (id) => `/api/suppliers/${id}`,
    STATS: '/api/suppliers/stats',
    CATEGORIES: '/api/suppliers/categories',
    COUNTRIES: '/api/suppliers/countries',
    EXPORT: '/api/suppliers/export',
    BULK: '/api/suppliers/bulk',
    PERFORMANCE: (id, period = '30d') => `/api/suppliers/${id}/performance?period=${period}`,
    CONTRACTS: (id) => `/api/suppliers/${id}/contracts`,
    ORDERS: (id) => `/api/suppliers/${id}/orders`
  },

  // Orders
  ORDERS: {
    BASE: '/api/orders',
    BY_ID: (id) => `/api/orders/${id}`,
    STATS: '/api/orders/stats',
    EXPORT: '/api/orders/export'
  },

  // Inventory
  INVENTORY: {
    BASE: '/api/inventory',
    BY_ID: (id) => `/api/inventory/${id}`,
    STATS: '/api/inventory/stats',
    CATEGORIES: '/api/inventory/categories'
  },

  // Payments
  PAYMENTS: {
    BASE: '/api/payments',
    BY_ID: (id) => `/api/payments/${id}`,
    STATS: '/api/payments/stats',
    EXPORT: '/api/payments/export'
  },

  // User Management
  USERS: {
    BASE: '/api/users',
    BY_ID: (id) => `/api/users/${id}`,
    ROLES: '/api/users/roles',
    PERMISSIONS: '/api/users/permissions'
  },

  // Audit Logs
  AUDIT: {
    BASE: '/api/audit',
    BY_ID: (id) => `/api/audit/${id}`,
    EXPORT: '/api/audit/export'
  }
};

// API Base URL Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || 'https://localhost:7034/api',
  TIMEOUT: 10000,
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000
};

// HTTP Methods
export const HTTP_METHODS = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE',
  PATCH: 'PATCH'
};

// Response Status Codes
export const STATUS_CODES = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  INTERNAL_SERVER_ERROR: 500
};
