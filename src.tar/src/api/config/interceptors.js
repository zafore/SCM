import axios from 'axios';
import { API_CONFIG, STATUS_CODES } from './endpoints.js';

// Request Interceptor
export const setupRequestInterceptor = (axiosInstance) => {
  axiosInstance.interceptors.request.use(
    async (config) => {
      // Add timestamp for debugging
      config.metadata = { startTime: new Date() };
      
      // Get token from localStorage
      const userData = localStorage.getItem('user');
      if (userData) {
        try {
          const parsedUserData = JSON.parse(userData);
          const token = parsedUserData.token;
          if (token) {
            config.headers.Authorization = `Bearer ${token}`;
            console.log('🔐 Adding Authorization header:', token.substring(0, 20) + '...');
          }
        } catch (error) {
          console.error('❌ Error parsing user data from localStorage:', error);
        }
      }

      // Add common headers
      config.headers['Content-Type'] = 'application/json';
      config.headers['Accept'] = 'application/json';
      
      // Add request ID for tracking
      config.headers['X-Request-ID'] = generateRequestId();
      
             // Only log in development mode
       if (import.meta.env.DEV) {
         console.log(`🚀 ${config.method?.toUpperCase()} ${config.url}`);
       }
      return config;
    },
    (error) => {
      console.error('❌ Request interceptor error:', error);
      return Promise.reject(error);
    }
  );
};

// Response Interceptor
export const setupResponseInterceptor = (axiosInstance) => {
  axiosInstance.interceptors.response.use(
    (response) => {
      // Calculate response time
      const endTime = new Date();
      const startTime = response.config.metadata?.startTime;
      const duration = startTime ? endTime - startTime : 0;
      
             // Only log in development mode
       if (import.meta.env.DEV) {
         console.log(`✅ ${response.config.method?.toUpperCase()} ${response.config.url} - ${response.status} (${duration}ms)`);
       }
      
      return response;
    },
    async (error) => {
      const endTime = new Date();
      const startTime = error.config?.metadata?.startTime;
      const duration = startTime ? endTime - startTime : 0;
      
             // Only log errors in development mode
       if (import.meta.env.DEV) {
         console.error(`❌ ${error.config?.method?.toUpperCase()} ${error.config?.url} - ${error.response?.status} (${duration}ms)`);
         console.error('Error details:', {
           status: error.response?.status,
           statusText: error.response?.statusText,
           data: error.response?.data,
           message: error.message
         });
       }

      // Handle specific error cases
      if (error.response?.status === STATUS_CODES.UNAUTHORIZED) {
        // Handle 401 - redirect to login or refresh token
        handleUnauthorizedError(error);
      } else if (error.response?.status === STATUS_CODES.FORBIDDEN) {
        // Handle 403 - show access denied message
        handleForbiddenError(error);
      } else if (error.response?.status === STATUS_CODES.NOT_FOUND) {
        // Handle 404 - show not found message
        handleNotFoundError(error);
      } else if (error.code === 'ERR_NETWORK') {
        // Handle network errors
        handleNetworkError(error);
      }

      return Promise.reject(error);
    }
  );
};

// Error Handlers
const handleUnauthorizedError = (error) => {
  console.log('🔐 Unauthorized - redirecting to login');
  localStorage.removeItem('user');
  window.location.href = '/login';
};

const handleForbiddenError = (error) => {
  console.log('🚫 Access denied - insufficient permissions');
  // Could show a toast notification here
};

const handleNotFoundError = (error) => {
  console.log('🔍 Resource not found');
  // Could show a toast notification here
};

const handleNetworkError = (error) => {
  console.log('🌐 Network error - check connection');
  // Could show a toast notification here
};

// Utility Functions
const generateRequestId = () => {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Retry Logic
export const retryRequest = async (axiosInstance, error, retryCount = 0) => {
  const maxRetries = parseInt(API_CONFIG.RETRY_ATTEMPTS) || 3;
  
  if (retryCount >= maxRetries) {
    return Promise.reject(error);
  }

  // Only retry on network errors or 5xx server errors
  if (error.code === 'ERR_NETWORK' || 
      (error.response?.status >= 500 && error.response?.status < 600)) {
    
    console.log(`🔄 Retrying request (${retryCount + 1}/${maxRetries})...`);
    
    // Wait before retrying
    await new Promise(resolve => setTimeout(resolve, (parseInt(API_CONFIG.RETRY_DELAY) || 1000) * (retryCount + 1)));
    
    // Retry the request
    return axiosInstance.request(error.config);
  }
  
  return Promise.reject(error);
};
