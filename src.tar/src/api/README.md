# API Interface Structure

This folder contains a well-organized API interface structure that follows best practices for maintainability, scalability, and consistency.

## 📁 Folder Structure

```
src/api/
├── config/                 # API Configuration
│   ├── endpoints.js        # Centralized endpoint definitions
│   └── interceptors.js     # Request/response interceptors
├── services/              # API Service Classes
│   ├── base.service.js    # Base service with common functionality
│   ├── auth.service.js    # Authentication service
│   └── supplier.service.js # Supplier management service
├── utils/                 # API Utilities
│   └── response.handler.js # Response standardization and error handling
└── index.js              # Main exports
```

## 🏗️ Architecture Benefits

### 1. **Centralized Configuration**
- All endpoints defined in one place (`config/endpoints.js`)
- Easy to maintain and update API URLs
- Consistent naming conventions
- Environment-specific configurations

### 2. **Standardized Response Handling**
- Consistent response format across all API calls
- Automatic error handling and logging
- Response transformation utilities
- Pagination support

### 3. **Reusable Base Service**
- Common HTTP methods (GET, POST, PUT, DELETE)
- Built-in retry logic with exponential backoff
- File upload/download capabilities
- Query parameter building utilities

### 4. **Enhanced Interceptors**
- Automatic token management
- Request/response logging
- Error categorization and handling
- Performance monitoring

### 5. **Service-Specific Logic**
- Domain-specific validation
- Data transformation
- Business logic encapsulation
- Type safety (when using TypeScript)

## 🚀 Usage Examples

### Basic Service Usage
```javascript
import { SupplierService, AuthService } from '../api/index.js';

// Get suppliers with pagination
const response = await SupplierService.getSuppliers({
  page: 1,
  pageSize: 10,
  search: 'ABC'
});

// Login user
const loginResult = await AuthService.login('username', 'password');
```

### Response Handling
```javascript
// All responses are standardized
if (response.success) {
  const suppliers = response.data;
  const totalCount = response.totalCount;
} else {
  console.error(response.message);
}
```

### Error Handling
```javascript
// Automatic error handling with detailed messages
const result = await SupplierService.createSupplier(supplierData);
if (!result.success) {
  // Handle specific error types
  switch (result.status) {
    case 401:
      // Redirect to login
      break;
    case 403:
      // Show access denied
      break;
    case 422:
      // Show validation errors
      break;
  }
}
```

## 🔧 Configuration

### Environment Variables
```javascript
// .env
VITE_API_BASE_URL=http://localhost:7133
VITE_API_TIMEOUT=10000
```

### Custom Endpoints
```javascript
// config/endpoints.js
export const API_ENDPOINTS = {
  SUPPLIERS: {
    BASE: '/api/suppliers',
    BY_ID: (id) => `/api/suppliers/${id}`,
    // Add more endpoints as needed
  }
};
```

## 🛡️ Error Handling

The API structure provides comprehensive error handling:

1. **Network Errors**: Automatic retry with exponential backoff
2. **Authentication Errors**: Automatic token refresh or logout
3. **Validation Errors**: Detailed error messages for form validation
4. **Server Errors**: Graceful degradation with user-friendly messages

## 📊 Monitoring & Logging

- Request/response logging with timestamps
- Performance metrics (response times)
- Error tracking and categorization
- Request ID tracking for debugging

## 🔄 Migration Guide

### From Old Structure
```javascript
// Old way
import api from '../services/SuppliersServices.js';
const response = await api.getSuppliers(params);

// New way
import { SupplierService } from '../api/index.js';
const response = await SupplierService.getSuppliers(params);
```

### Benefits of Migration
- ✅ Better error handling
- ✅ Consistent response format
- ✅ Centralized configuration
- ✅ Improved maintainability
- ✅ Enhanced debugging capabilities
- ✅ Better separation of concerns

## 🎯 Best Practices

1. **Always use the service classes** instead of direct axios calls
2. **Handle responses consistently** using the standardized format
3. **Use the validation methods** provided by services
4. **Leverage the retry logic** for network resilience
5. **Monitor performance** using the built-in logging
6. **Keep endpoints centralized** in the config files

## 🔮 Future Enhancements

- TypeScript interfaces for type safety
- GraphQL support
- WebSocket integration
- Caching layer
- Request/response compression
- API versioning support
