import AuthService from '../services/AuthServices.js';

// Check if user is authenticated
export const isAuthenticated = () => {
  return AuthService.isLoggedIn();
};

// Get current user
export const getCurrentUser = () => {
  return AuthService.getCurrentUser();
};

// Get user role
export const getUserRole = () => {
  return AuthService.getUserRole();
};

// Check if user has specific role
export const hasRole = (requiredRole) => {
  const userRole = getUserRole();
  return userRole === requiredRole;
};

// Check if user has any of the required roles
export const hasAnyRole = (requiredRoles) => {
  const userRole = getUserRole();
  return requiredRoles.includes(userRole);
};

// Check if user has all required roles
export const hasAllRoles = (requiredRoles) => {
  const userRole = getUserRole();
  return requiredRoles.every(role => userRole === role);
};

// Get token
export const getToken = () => {
  return AuthService.getToken();
};

// Logout user
export const logout = () => {
  AuthService.logout();
  window.location.href = '/login';
};

// Require authentication - redirect to login if not authenticated
export const requireAuth = () => {
  if (!isAuthenticated()) {
    logout();
    return false;
  }
  return true;
};

// Require specific role - redirect to unauthorized if not authorized
export const requireRole = (requiredRole) => {
  if (!isAuthenticated()) {
    logout();
    return false;
  }
  
  if (!hasRole(requiredRole)) {
    window.location.href = '/unauthorized';
    return false;
  }
  
  return true;
};

// Require any of the specified roles
export const requireAnyRole = (requiredRoles) => {
  if (!isAuthenticated()) {
    logout();
    return false;
  }
  
  if (!hasAnyRole(requiredRoles)) {
    window.location.href = '/unauthorized';
    return false;
  }
  
  return true;
};
