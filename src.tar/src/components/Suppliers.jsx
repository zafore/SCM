import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';
import { getToken, isAuthenticated } from '../utils/authUtils.js';
import '../styles/design-system.css';

const Suppliers = () => {
  const { t } = useTranslation();
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCountry, setFilterCountry] = useState('all');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [suppliersPerPage] = useState(10);
  const [totalSuppliers, setTotalSuppliers] = useState(0);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    pending: 0,
    inactive: 0,
    totalRevenue: 0
  });

  const [formData, setFormData] = useState({
    supplierName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    contactPerson: '',
    website: '',
    status: 'Active',
    rating: 0,
    notes: '',
    contractExpiry: '',
    paymentTerms: 'Net 30',
    category: 'General',
    taxId: '',
    bankDetails: ''
  });

  // Test authorization function
  const testAuthorization = () => {
    const token = getToken();
    const authenticated = isAuthenticated();
    
    console.log('=== Authorization Test ===');
    console.log('Is Authenticated:', authenticated);
    console.log('Token:', token ? token.substring(0, 50) + '...' : 'No token');
    console.log('Token Length:', token ? token.length : 0);
    
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        console.log('Token Payload:', payload);
        console.log('Token Expiry:', new Date(payload.exp * 1000));
        console.log('Token Issued:', new Date(payload.iat * 1000));
        console.log('User Role:', payload.role);
        console.log('User Name:', payload.nameid);
      } catch (error) {
        console.error('Error parsing token:', error);
      }
    }
    
    displayAlert('Authorization test completed. Check console for details.', 'info');
  };

  // Set test token function
  const setTestToken = () => {
    const testToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1laWQiOiJhZG1pbiIsImVtYWlsIjoiYWRtaW4iLCJyb2xlIjoiQWRtaW4iLCJuYmYiOjE3NTY1NDExNjksImV4cCI6MTc1NjU0NDc2OSwiaWF0IjoxNzU2NTQxMTY5LCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjcxMzMiLCJhdWQiOiJodHRwOi8vbG9jYWxob3N0OjcwMzQifQ.ZWmgWRqnjkdQiSiy0OBhwGosJoJrAUcJTmprFOtELxg';
    // Store token directly in localStorage in the correct format
    const userData = {
      token: testToken,
      user: {
        nameid: 'admin',
        email: 'admin',
        role: 'Admin'
      },
      role: 'Admin'
    };
    localStorage.setItem('user', JSON.stringify(userData));
    displayAlert('Test token set successfully!', 'success');
    console.log('Test token set:', testToken.substring(0, 50) + '...');
  };

  // Test API call with authorization
  const testApiCall = async () => {
    try {
      console.log('=== Testing API Call with Authorization ===');
      const response = await api.getSuppliers({ page: 1, pageSize: 5 });
      console.log('API Response:', response);
      displayAlert('API call successful! Check console for details.', 'success');
    } catch (error) {
      console.error('API Call Error:', error);
      displayAlert('API call failed. Check console for details.', 'danger');
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      fetchSuppliers();
    }, 300); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [currentPage, searchTerm, filterStatus, filterCountry]);

  useEffect(() => {
    if (suppliers.length > 0) {
      updateStats();
    }
  }, [suppliers]);

  const fetchSuppliers = async () => {
    try {
      setLoading(true);
      
      // Build query parameters
      const params = {
        page: currentPage,
        pageSize: suppliersPerPage,
        search: searchTerm,
        status: filterStatus !== 'all' ? filterStatus : '',
        country: filterCountry !== 'all' ? filterCountry : ''
      };

      const response = await api.get(ENDPOINTS.SUPPLIERS, { params });
      
      // Ensure we always have an array of suppliers
      let suppliersData = [];
      let totalCount = 0;
      
      if (response && response.data) {
        // Handle original API response format
        if (Array.isArray(response.data)) {
          suppliersData = response.data;
          totalCount = response.data.length;
        } else if (response.data.items && Array.isArray(response.data.items)) {
          suppliersData = response.data.items;
          totalCount = response.data.totalCount || response.data.items.length;
        } else {
          console.warn('Unexpected response structure:', response);
          suppliersData = [];
          totalCount = 0;
        }
      } else {
        // No response or unexpected format
        console.warn('No response or unexpected format:', response);
        suppliersData = [];
        totalCount = 0;
      }
      
      setSuppliers(suppliersData);
      setTotalSuppliers(totalCount);
      
    } catch (error) {
      // Only log in development mode
      if (import.meta.env.DEV) {
        console.error('Error fetching suppliers:', error);
      }
      
      // Handle different types of errors gracefully
      let errorMessage = 'Error fetching suppliers';
      
      if (error.response?.status === 401) {
        errorMessage = 'Authentication failed. Please check your login.';
      } else if (error.response?.status === 403) {
        errorMessage = 'Access denied. You do not have permission to view suppliers.';
      } else if (error.response?.status === 404) {
        errorMessage = 'API endpoint not found. Backend service may not be running.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error. Please try again later.';
      } else if (error.code === 'ERR_NETWORK') {
        errorMessage = 'Network error. Backend service is not running.';
      } else if (error.response?.data?.message) {
        errorMessage += ': ' + error.response.data.message;
      } else if (error.message) {
        errorMessage += ': ' + error.message;
      }
      
      // Fallback to mock data for development
      if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
        console.log('API not available, using mock data for demonstration');
        const mockSuppliers = generateMockSuppliers();
        setSuppliers(mockSuppliers);
        setTotalSuppliers(mockSuppliers.length);
        displayAlert('Using mock data (API not available)', 'info');
      } else {
        displayAlert(errorMessage, 'danger');
        // Set empty array to prevent filter errors
        setSuppliers([]);
        setTotalSuppliers(0);
      }
    } finally {
      setLoading(false);
    }
  };

  const updateStats = () => {
    if (!Array.isArray(suppliers)) {
      setStats({
        total: 0,
        active: 0,
        pending: 0,
        inactive: 0,
        totalRevenue: 0
      });
      return;
    }
    
    setStats({
      total: suppliers.length,
      active: suppliers.filter(s => s.status === 'Active').length,
      pending: suppliers.filter(s => s.status === 'Pending').length,
      inactive: suppliers.filter(s => s.status === 'Inactive').length,
      totalRevenue: suppliers.reduce((sum, s) => sum + (s.totalSpent || 0), 0)
    });
  };

  const generateMockSuppliers = () => {
    // Use a more efficient approach for mock data
    const mockData = [];
    for (let i = 1; i <= 5; i++) {
      mockData.push({
        id: i,
        supplierId: i,
        supplierName: `Supplier ${i}`,
        email: `supplier${i}@example.com`,
        phone: `+1-555-010${i}`,
        address: `${i}23 Business Ave`,
        city: 'New York',
        country: 'USA',
        contactPerson: `Contact ${i}`,
        website: `www.supplier${i}.com`,
        status: i % 3 === 0 ? 'Pending' : 'Active',
        rating: 4 + (i % 10) / 10,
        notes: `Mock supplier ${i}`,
        contractExpiry: '2024-12-31',
        totalOrders: 20 + i * 5,
        totalSpent: 50000 + i * 10000,
        category: 'General',
        paymentTerms: 'Net 30',
        taxId: `US${i}23456789`,
        bankDetails: `Bank - ****${i}234`
      });
    }
    return mockData;
  };

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      
      console.log('Submitting supplier data:', formData);
      console.log('API endpoint:', ENDPOINTS.SUPPLIERS);
      
      if (editingSupplier) {
        // Update existing supplier
        console.log('Updating supplier:', editingSupplier.id);
        const response = await api.updateSupplier(editingSupplier.id, formData);
        if (response) {
          displayAlert('Supplier updated successfully', 'success');
          setOpenDialog(false);
          fetchSuppliers();
        }
      } else {
        // Create new supplier
        console.log('Creating new supplier');
        const response = await api.createSupplier(formData);
        if (response) {
          displayAlert('Supplier created successfully', 'success');
          setOpenDialog(false);
          fetchSuppliers();
        }
      }
    } catch (error) {
      console.error('Error saving supplier:', error);
      console.error('Error details:', {
        status: error.response?.status,
        statusText: error.response?.statusText,
        data: error.response?.data,
        message: error.message,
        code: error.code,
        config: {
          url: error.config?.url,
          method: error.config?.method,
          headers: error.config?.headers
        }
      });
      
      // Handle different types of errors gracefully
      let errorMessage = 'Error saving supplier';
      
      if (error.response?.status === 401) {
        errorMessage = 'Authentication failed. Please check your login.';
      } else if (error.response?.status === 403) {
        errorMessage = 'Access denied. You do not have permission to perform this action.';
      } else if (error.response?.status === 404) {
        errorMessage = 'API endpoint not found. Backend service may not be running.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error. Please try again later.';
      } else if (error.code === 'ERR_NETWORK') {
        errorMessage = 'Network error. Please check your connection or backend service.';
      } else if (error.response?.data?.message) {
        errorMessage += ': ' + error.response.data.message;
      } else if (error.message) {
        errorMessage += ': ' + error.message;
      }
      
      displayAlert(errorMessage, 'danger');
      
      // For development, add the supplier to the local state if API fails
      if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
        console.log('API not available, adding supplier to local state for development');
        const newSupplier = {
          id: Date.now(), // Generate temporary ID
          ...formData,
          totalOrders: 0,
          totalSpent: 0,
          createdAt: new Date().toISOString()
        };
        
        setSuppliers(prev => [newSupplier, ...prev]);
        setTotalSuppliers(prev => prev + 1);
        displayAlert('Supplier added to local state (API not available)', 'warning');
        setOpenDialog(false);
        fetchSuppliers();
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      supplierName: supplier.supplierName || '',
      email: supplier.email || '',
      phone: supplier.phone || '',
      address: supplier.address || '',
      city: supplier.city || '',
      country: supplier.country || '',
      contactPerson: supplier.contactPerson || '',
      website: supplier.website || '',
      status: supplier.status || 'Active',
      rating: supplier.rating || 0,
      notes: supplier.notes || '',
      contractExpiry: supplier.contractExpiry || '',
      paymentTerms: supplier.paymentTerms || 'Net 30',
      category: supplier.category || 'General',
      taxId: supplier.taxId || '',
      bankDetails: supplier.bankDetails || ''
    });
    setOpenDialog(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this supplier? This action cannot be undone.')) {
      try {
        setLoading(true);
        await api.deleteSupplier(id);
        displayAlert('Supplier deleted successfully', 'success');
        fetchSuppliers();
      } catch (error) {
        console.error('Error deleting supplier:', error);
        
        // Handle different types of errors gracefully
        let errorMessage = 'Error deleting supplier';
        
        if (error.response?.status === 401) {
          errorMessage = 'Authentication failed. Please check your login.';
        } else if (error.response?.status === 403) {
          errorMessage = 'Access denied. You do not have permission to perform this action.';
        } else if (error.response?.status === 404) {
          errorMessage = 'API endpoint not found. Backend service may not be running.';
        } else if (error.response?.status === 500) {
          errorMessage = 'Server error. Please try again later.';
        } else if (error.code === 'ERR_NETWORK') {
          errorMessage = 'Network error. Please check your connection or backend service.';
        } else if (error.response?.data?.message) {
          errorMessage += ': ' + error.response.data.message;
        } else if (error.message) {
          errorMessage += ': ' + error.message;
        }
        
        displayAlert(errorMessage, 'danger');
        
        // For development, remove the supplier from local state if API fails
        if (error.response?.status === 404 || error.code === 'ERR_NETWORK') {
          console.log('API not available, removing supplier from local state for development');
          setSuppliers(prev => prev.filter(s => s.id !== id));
          setTotalSuppliers(prev => prev - 1);
          displayAlert('Supplier removed from local state (API not available)', 'warning');
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAddNew = () => {
    setEditingSupplier(null);
    setFormData({
      supplierName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      country: '',
      contactPerson: '',
      website: '',
      status: 'Active',
      rating: 0,
      notes: '',
      contractExpiry: '',
      paymentTerms: 'Net 30',
      category: 'General',
      taxId: '',
      bankDetails: ''
    });
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingSupplier(null);
    setFormData({
      supplierName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      country: '',
      contactPerson: '',
      website: '',
      status: 'Active',
      rating: 0,
      notes: '',
      contractExpiry: '',
      paymentTerms: 'Net 30',
      category: 'General',
      taxId: '',
      bankDetails: ''
    });
  };

  // Filter suppliers based on search and filters
  const filteredSuppliers = Array.isArray(suppliers) ? suppliers.filter(supplier => {
    console.log(supplier.supplierId);
    const matchesSearch = supplier.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || supplier.status === filterStatus;
    const matchesCountry = filterCountry === 'all' || supplier.country === filterCountry;
    
    return matchesSearch && matchesStatus && matchesCountry;
  }) : [];

  // Pagination
  const totalPages = Math.ceil(totalSuppliers / suppliersPerPage);

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Active':
        return 'badge-status-active';
      case 'Inactive':
        return 'badge-status-inactive';
      case 'Pending':
        return 'badge-status-pending';
      default:
        return 'badge-status-inactive';
    }
  };

  const getRatingStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i} className="text-warning">⭐</span>);
    }
    
    if (hasHalfStar) {
      stars.push(<span key="half" className="text-warning">⭐</span>);
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="text-muted">☆</span>);
    }
    
    return <>{stars}</>;
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Technology': '💻',
      'Office Supplies': '📎',
      'Furniture': '🪑',
      'Logistics': '🚚',
      'Energy': '⚡',
      'General': '🏢'
    };
    return icons[category] || '🏢';
  };

  if (loading) {
    return (
      <div className="suppliers-container fade-in-up">
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-3 text-muted">Loading suppliers...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="suppliers-container fade-in-up">
      {/* Development Mode Banner */}
      <div className="alert alert-warning alert-dismissible fade show mb-3" role="alert">
        <div className="d-flex align-items-center">
          <i className="bi bi-exclamation-triangle me-2"></i>
          <strong>Development Mode:</strong>
          <span className="ms-2">API endpoints may not be available. Using mock data and local state for development.</span>
        </div>
        <button type="button" className="btn-close" data-bs-dismiss="alert"></button>
      </div>
      
      {/* Enhanced Header Section */}
      <div className="suppliers-header card-enhanced mb-4">
        <div className="card-body p-4">
          <div className="row align-items-center">
            <div className="col-md-8">
              <h1 className="display-6 fw-bold text-dark mb-2">
                <i className="bi bi-building me-3"></i>
                Supplier Management
              </h1>
              <p className="text-muted mb-0 fs-5">
                Manage your supplier relationships, contracts, and performance metrics
              </p>
            </div>
                         <div className="col-md-4 text-end">
               <div className="d-flex gap-2 justify-content-end">
                 <button 
                   className="btn btn-outline-warning btn-sm"
                   onClick={setTestToken}
                   title="Set Test Token"
                 >
                   <i className="bi bi-key me-2"></i>
                   Set Token
                 </button>
                 <button 
                   className="btn btn-outline-info btn-sm"
                   onClick={testAuthorization}
                   title="Test Authorization"
                 >
                   <i className="bi bi-shield-check me-2"></i>
                   Test Auth
                 </button>
                 <button 
                   className="btn btn-outline-success btn-sm"
                   onClick={testApiCall}
                   title="Test API Call"
                 >
                   <i className="bi bi-arrow-right-circle me-2"></i>
                   Test API
                 </button>
                 <button 
                   className="btn btn-primary-enhanced btn-lg"
                   onClick={handleAddNew}
                 >
                   <i className="bi bi-plus-circle me-2"></i>
                   Add New Supplier
                 </button>
               </div>
             </div>
          </div>
        </div>
      </div>

      {/* Enhanced Stats Cards */}
      <div className="row g-4 mb-4">
        <div className="col-xl-2 col-md-4 col-sm-6">
          <div className="card-enhanced h-100 stats-card">
            <div className="card-body p-3 text-center">
              <div className="stats-icon mb-2" style={{ fontSize: '2rem' }}>🏢</div>
              <h3 className="h4 mb-1 fw-bold text-primary">{stats.total}</h3>
              <p className="text-muted mb-0 small">Total Suppliers</p>
            </div>
          </div>
        </div>
        <div className="col-xl-2 col-md-4 col-sm-6">
          <div className="card-enhanced h-100 stats-card">
            <div className="card-body p-3 text-center">
              <div className="stats-icon mb-2" style={{ fontSize: '2rem' }}>✅</div>
              <h3 className="h4 mb-1 fw-bold text-success">{stats.active}</h3>
              <p className="text-muted mb-0 small">Active</p>
            </div>
          </div>
        </div>
        <div className="col-xl-2 col-md-4 col-sm-6">
          <div className="card-enhanced h-100 stats-card">
            <div className="card-body p-3 text-center">
              <div className="stats-icon mb-2" style={{ fontSize: '2rem' }}>⏳</div>
              <h3 className="h4 mb-1 fw-bold text-warning">{stats.pending}</h3>
              <p className="text-muted mb-0 small">Pending</p>
            </div>
          </div>
        </div>
        <div className="col-xl-2 col-md-4 col-sm-6">
          <div className="card-enhanced h-100 stats-card">
            <div className="card-body p-3 text-center">
              <div className="stats-icon mb-2" style={{ fontSize: '2rem' }}>❌</div>
              <h3 className="h4 mb-1 fw-bold text-danger">{stats.inactive}</h3>
              <p className="text-muted mb-0 small">Inactive</p>
            </div>
          </div>
        </div>
        <div className="col-xl-4 col-md-8 col-sm-12">
          <div className="card-enhanced h-100 stats-card">
            <div className="card-body p-3 text-center">
              <div className="stats-icon mb-2" style={{ fontSize: '2rem' }}>💰</div>
              <h3 className="h4 mb-1 fw-bold text-success">
                ${stats.totalRevenue.toLocaleString()}
              </h3>
              <p className="text-muted mb-0 small">Total Revenue Generated</p>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType}-enhanced alert-dismissible fade show mb-4`} role="alert">
          <div className="d-flex align-items-center">
            <i className={`bi bi-${alertType === 'success' ? 'check-circle' : 'exclamation-triangle'} me-3 fs-5`}></i>
            <div>
              <strong>{alertType === 'success' ? 'Success!' : 'Error!'}</strong>
              <div className="mt-1">{alertMessage}</div>
            </div>
          </div>
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Enhanced Filters and Search */}
      <div className="card-enhanced mb-4">
        <div className="card-body p-4">
          <div className="row g-3">
            <div className="col-md-4">
              <div className="search-container">
                <i className="bi bi-search search-icon"></i>
                <input
                  type="text"
                  className="form-control-enhanced"
                  placeholder="Search suppliers by name, email, contact person, or city..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-3">
              <select 
                className="form-select form-select-enhanced"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Pending">Pending</option>
              </select>
            </div>
            <div className="col-md-3">
              <select 
                className="form-select form-select-enhanced"
                value={filterCountry}
                onChange={(e) => setFilterCountry(e.target.value)}
              >
                <option value="all">All Countries</option>
                <option value="USA">USA</option>
                <option value="UK">UK</option>
                <option value="Canada">Canada</option>
                <option value="Germany">Germany</option>
                <option value="France">France</option>
                <option value="Japan">Japan</option>
                <option value="Australia">Australia</option>
              </select>
            </div>
            <div className="col-md-2">
              <button 
                className="btn btn-outline-secondary w-100"
                onClick={() => {
                  setSearchTerm('');
                  setFilterStatus('all');
                  setFilterCountry('all');
                  setCurrentPage(1);
                }}
              >
                <i className="bi bi-arrow-clockwise me-2"></i>
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Suppliers Table */}
      <div className="card-enhanced">
        <div className="card-header">
          <div className="d-flex justify-content-between align-items-center">
            <h5 className="fw-semibold text-dark mb-0">
              <i className="bi bi-list-ul me-2"></i>
              Suppliers ({filteredSuppliers.length} of {totalSuppliers})
            </h5>
            <div className="d-flex gap-2">
              <button 
                className="btn btn-outline-primary btn-sm"
                onClick={() => api.exportSuppliers({ status: filterStatus, country: filterCountry })}
              >
                <i className="bi bi-download me-2"></i>
                Export CSV
              </button>
              <button className="btn btn-outline-info btn-sm">
                <i className="bi bi-graph-up me-2"></i>
                Analytics
              </button>
              <button className="btn btn-outline-secondary btn-sm">
                <i className="bi bi-gear me-2"></i>
                Settings
              </button>
            </div>
          </div>
        </div>
        
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-enhanced mb-0">
              <thead>
                <tr>
                  <th>Supplier</th>
                  <th>Contact</th>
                  <th>Location</th>
                  <th>Status</th>
                  <th>Rating</th>
                  <th>Performance</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredSuppliers.map((supplier) => (
                 
                  <tr key={supplier.supplierId} className="supplier-row">
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="supplier-avatar me-3">
                          {getCategoryIcon(supplier.category)}
                        </div>
                        <div>
                          <h6 className="fw-semibold mb-1">{supplier.supplierName}</h6>
                          <small className="text-muted">
                            <i className="bi bi-tag me-1"></i>
                            {supplier.category}
                          </small>
                          <br />
                          <small className="text-muted">
                            <i className="bi bi-globe me-1"></i>
                            {supplier.website}
                          </small>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div>
                        <div className="fw-medium">{supplier.contactPerson}</div>
                        <small className="text-muted">
                          <i className="bi bi-envelope me-1"></i>
                          {supplier.email}
                        </small>
                        <br />
                        <small className="text-muted">
                          <i className="bi bi-telephone me-1"></i>
                          {supplier.phone}
                        </small>
                      </div>
                    </td>
                    <td>
                      <div>
                        <div className="fw-medium">{supplier.city}</div>
                        <small className="text-muted">
                          <i className="bi bi-geo-alt me-1"></i>
                          {supplier.country}
                        </small>
                        {supplier.contractExpiry && (
                          <React.Fragment>
                            <br />
                            <small className="text-muted">
                              <i className="bi bi-calendar me-1"></i>
                              Expires: {new Date(supplier.contractExpiry).toLocaleDateString()}
                            </small>
                          </React.Fragment>
                        )}
                      </div>
                    </td>
                    <td>
                      <span className={`badge-enhanced ${getStatusBadgeClass(supplier.status)}`}>
                        {supplier.status}
                      </span>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="me-2">
                          {getRatingStars(supplier.rating)}
                        </div>
                        <span className="fw-semibold text-muted">
                          {supplier.rating.toFixed(1)}
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="performance-metrics">
                        <div className="d-flex justify-content-between mb-1">
                          <small className="text-muted">Orders</small>
                          <small className="fw-semibold">{supplier.totalOrders}</small>
                        </div>
                        <div className="d-flex justify-content-between">
                          <small className="text-muted">Revenue</small>
                          <small className="fw-semibold text-success">
                            ${supplier.totalSpent.toLocaleString()}
                          </small>
                        </div>
                        {supplier.paymentTerms && (
                          <div className="d-flex justify-content-between">
                            <small className="text-muted">Terms</small>
                            <small className="fw-semibold text-info">
                              {supplier.paymentTerms}
                            </small>
                          </div>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="d-flex gap-1">
                        <button 
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => handleEdit(supplier)}
                          title="Edit Supplier"
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button 
                          className="btn btn-sm btn-outline-info"
                          title="View Details"
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button 
                          className="btn btn-sm btn-outline-warning"
                          title="View Contracts"
                        >
                          <i className="bi bi-file-text"></i>
                        </button>
                        <button 
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => handleDelete(supplier.id)}
                          title="Delete Supplier"
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Enhanced Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav aria-label="Suppliers pagination">
            <ul className="pagination pagination-enhanced">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => setCurrentPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  <i className="bi bi-chevron-left"></i>
                </button>
              </li>
              
              {(() => {
                const pages = [];
                const maxVisible = 5;
                let startPage = 1;
                let endPage = totalPages;
                
                if (totalPages > maxVisible) {
                  if (currentPage <= 3) {
                    endPage = maxVisible;
                  } else if (currentPage >= totalPages - 2) {
                    startPage = totalPages - maxVisible + 1;
                  } else {
                    startPage = currentPage - 2;
                    endPage = currentPage + 2;
                  }
                }
                
                for (let page = startPage; page <= endPage; page++) {
                  pages.push(
                    <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                      <button 
                        className="page-link"
                        onClick={() => setCurrentPage(page)}
                      >
                        {page}
                      </button>
                    </li>
                  );
                }
                
                return pages;
              })()}
              
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  <i className="bi bi-chevron-right"></i>
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Enhanced Add/Edit Modal */}
      {openDialog && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-xl modal-dialog-centered">
            <div className="modal-content modal-enhanced">
              <div className="modal-header">
                <h5 className="modal-title fw-semibold">
                  <i className="bi bi-building me-2"></i>
                  {editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}
                </h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={handleCloseDialog}
                ></button>
              </div>
              
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="row g-3">
                    {/* Basic Information */}
                    <div className="col-12">
                      <h6 className="text-primary mb-3">
                        <i className="bi bi-info-circle me-2"></i>
                        Basic Information
                      </h6>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Supplier Name *</label>
                      <input
                        type="text"
                        className="form-control-enhanced"
                        value={formData.supplierName}
                        onChange={(e) => setFormData({...formData, supplierName: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Category</label>
                      <select
                        className="form-select form-select-enhanced"
                        value={formData.category}
                        onChange={(e) => setFormData({...formData, category: e.target.value})}
                      >
                        <option value="General">General</option>
                        <option value="Technology">Technology</option>
                        <option value="Office Supplies">Office Supplies</option>
                        <option value="Furniture">Furniture</option>
                        <option value="Logistics">Logistics</option>
                        <option value="Energy">Energy</option>
                        <option value="Manufacturing">Manufacturing</option>
                        <option value="Services">Services</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Contact Person *</label>
                      <input
                        type="text"
                        className="form-control-enhanced"
                        value={formData.contactPerson}
                        onChange={(e) => setFormData({...formData, contactPerson: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Status</label>
                      <select
                        className="form-select form-select-enhanced"
                        value={formData.status}
                        onChange={(e) => setFormData({...formData, status: e.target.value})}
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending">Pending</option>
                      </select>
                    </div>

                    {/* Contact Information */}
                    <div className="col-12">
                      <h6 className="text-primary mb-3">
                        <i className="bi bi-telephone me-2"></i>
                        Contact Information
                      </h6>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Email *</label>
                      <input
                        type="email"
                        className="form-control-enhanced"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Phone *</label>
                      <input
                        type="tel"
                        className="form-control-enhanced"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Website</label>
                      <input
                        type="url"
                        className="form-control-enhanced"
                        value={formData.website}
                        onChange={(e) => setFormData({...formData, website: e.target.value})}
                        placeholder="https://example.com"
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Rating</label>
                      <input
                        type="number"
                        className="form-control-enhanced"
                        min="0"
                        max="5"
                        step="0.1"
                        value={formData.rating}
                        onChange={(e) => setFormData({...formData, rating: parseFloat(e.target.value)})}
                      />
                    </div>

                    {/* Location Information */}
                    <div className="col-12">
                      <h6 className="text-primary mb-3">
                        <i className="bi bi-geo-alt me-2"></i>
                        Location Information
                      </h6>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">City</label>
                      <input
                        type="text"
                        className="form-control-enhanced"
                        value={formData.city}
                        onChange={(e) => setFormData({...formData, city: e.target.value})}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Country</label>
                      <select
                        className="form-select form-select-enhanced"
                        value={formData.country}
                        onChange={(e) => setFormData({...formData, country: e.target.value})}
                      >
                        <option value="">Select Country</option>
                        <option value="USA">USA</option>
                        <option value="UK">UK</option>
                        <option value="Canada">Canada</option>
                        <option value="Germany">Germany</option>
                        <option value="France">France</option>
                        <option value="Japan">Japan</option>
                        <option value="Australia">Australia</option>
                        <option value="China">China</option>
                        <option value="India">India</option>
                        <option value="Brazil">Brazil</option>
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label fw-semibold">Address</label>
                      <textarea
                        className="form-control-enhanced"
                        rows="2"
                        value={formData.address}
                        onChange={(e) => setFormData({...formData, address: e.target.value})}
                      ></textarea>
                    </div>

                    {/* Business Information */}
                    <div className="col-12">
                      <h6 className="text-primary mb-3">
                        <i className="bi bi-briefcase me-2"></i>
                        Business Information
                      </h6>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Contract Expiry</label>
                      <input
                        type="date"
                        className="form-control-enhanced"
                        value={formData.contractExpiry}
                        onChange={(e) => setFormData({...formData, contractExpiry: e.target.value})}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Payment Terms</label>
                      <select
                        className="form-select form-select-enhanced"
                        value={formData.paymentTerms}
                        onChange={(e) => setFormData({...formData, paymentTerms: e.target.value})}
                      >
                        <option value="Net 15">Net 15</option>
                        <option value="Net 30">Net 30</option>
                        <option value="Net 45">Net 45</option>
                        <option value="Net 60">Net 60</option>
                        <option value="Net 90">Net 90</option>
                        <option value="COD">COD</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Tax ID</label>
                      <input
                        type="text"
                        className="form-control-enhanced"
                        value={formData.taxId}
                        onChange={(e) => setFormData({...formData, taxId: e.target.value})}
                        placeholder="Tax identification number"
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold">Bank Details</label>
                      <input
                        type="text"
                        className="form-control-enhanced"
                        value={formData.bankDetails}
                        onChange={(e) => setFormData({...formData, bankDetails: e.target.value})}
                        placeholder="Bank name and account details"
                      />
                    </div>

                    {/* Additional Information */}
                    <div className="col-12">
                      <h6 className="text-primary mb-3">
                        <i className="bi bi-chat-text me-2"></i>
                        Additional Information
                      </h6>
                    </div>
                    <div className="col-12">
                      <label className="form-label fw-semibold">Notes</label>
                      <textarea
                        className="form-control-enhanced"
                        rows="3"
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                        placeholder="Additional notes about this supplier, special requirements, or important information..."
                      ></textarea>
                    </div>
                  </div>
                </div>
                
                <div className="modal-footer">
                  <button 
                    type="button" 
                    className="btn btn-outline-secondary" 
                    onClick={handleCloseDialog}
                  >
                    <i className="bi bi-x-circle me-2"></i>
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary-enhanced"
                    disabled={loading}
                  >
                    {loading ? (
                      <React.Fragment>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        {editingSupplier ? 'Updating...' : 'Creating...'}
                      </React.Fragment>
                    ) : (
                      <React.Fragment>
                        <i className="bi bi-check-circle me-2"></i>
                        {editingSupplier ? 'Update Supplier' : 'Add Supplier'}
                      </React.Fragment>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Suppliers;
