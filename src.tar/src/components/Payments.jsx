import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const Payments = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterMethod, setFilterMethod] = useState('all');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [paymentsPerPage] = useState(10);

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      // Mock data since we don't have payments endpoint yet
      const mockPayments = [
        {
          id: 1,
          paymentNumber: 'PAY-2024-001',
          orderNumber: 'ORD-2024-001',
          supplierName: 'ABC Supplies Ltd',
          amount: 5000.00,
          paymentDate: '2024-01-15',
          dueDate: '2024-01-20',
          status: 'Completed',
          paymentMethod: 'Bank Transfer',
          reference: 'TXN-123456',
          description: 'Office supplies and equipment',
          currency: 'USD'
        },
        {
          id: 2,
          paymentNumber: 'PAY-2024-002',
          orderNumber: 'ORD-2024-002',
          supplierName: 'Tech Solutions Inc',
          amount: 12000.00,
          paymentDate: '2024-01-16',
          dueDate: '2024-01-25',
          status: 'Pending',
          paymentMethod: 'Check',
          reference: 'CHK-789012',
          description: 'Software licenses and maintenance',
          currency: 'USD'
        },
        {
          id: 3,
          paymentNumber: 'PAY-2024-003',
          orderNumber: 'ORD-2024-003',
          supplierName: 'Office Furniture Co',
          amount: 8500.00,
          paymentDate: '2024-01-17',
          dueDate: '2024-01-22',
          status: 'Completed',
          paymentMethod: 'Credit Card',
          reference: 'CC-345678',
          description: 'Conference room furniture',
          currency: 'USD'
        },
        {
          id: 4,
          paymentNumber: 'PAY-2024-004',
          orderNumber: 'ORD-2024-004',
          supplierName: 'Marketing Partners LLC',
          amount: 3200.00,
          paymentDate: '2024-01-18',
          dueDate: '2024-01-28',
          status: 'Failed',
          paymentMethod: 'Bank Transfer',
          reference: 'TXN-901234',
          description: 'Digital marketing services',
          currency: 'USD'
        }
      ];
      setPayments(mockPayments);
    } catch (error) {
      console.error('Error fetching payments:', error);
      displayAlert('Error fetching payments', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Completed':
        return '✅';
      case 'Pending':
        return '⏳';
      case 'Failed':
        return '❌';
      default:
        return '💰';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed':
        return 'success';
      case 'Pending':
        return 'warning';
      case 'Failed':
        return 'danger';
      default:
        return 'info';
    }
  };

  const getMethodIcon = (method) => {
    switch (method) {
      case 'Bank Transfer':
        return '🏦';
      case 'Check':
        return '📄';
      case 'Credit Card':
        return '💳';
      case 'Cash':
        return '💵';
      default:
        return '💰';
    }
  };

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = payment.paymentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.reference.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || payment.status === filterStatus;
    const matchesMethod = filterMethod === 'all' || payment.paymentMethod === filterMethod;
    return matchesSearch && matchesStatus && matchesMethod;
  });

  // Pagination
  const indexOfLastPayment = currentPage * paymentsPerPage;
  const indexOfFirstPayment = indexOfLastPayment - paymentsPerPage;
  const currentPayments = filteredPayments.slice(indexOfFirstPayment, indexOfLastPayment);
  const totalPages = Math.ceil(filteredPayments.length / paymentsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const processPayment = () => {
    displayAlert('Process payment feature coming soon!', 'info');
  };

  const exportPayments = () => {
    displayAlert('Export functionality coming soon!', 'info');
  };

  const getTotalAmount = (status = null) => {
    const paymentsToSum = status ? payments.filter(p => p.status === status) : payments;
    return paymentsToSum.reduce((sum, payment) => sum + payment.amount, 0);
  };

  const getPaymentCount = (status = null) => {
    return status ? payments.filter(p => p.status === status).length : payments.length;
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="payments-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">💰 Payments Management</h2>
              <p className="text-muted mb-0">Track and manage supplier payments</p>
            </div>
            <div className="btn-group">
              <button className="btn btn-outline-secondary" onClick={fetchPayments}>
                <span className="me-2">🔄</span>Refresh
              </button>
              <button className="btn btn-primary" onClick={processPayment}>
                <span className="me-2">➕</span>Process Payment
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Payments</h6>
                  <h4 className="mb-0">${getTotalAmount().toLocaleString()}</h4>
                  <small>{getPaymentCount()} payments</small>
                </div>
                <div className="fs-1">💰</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Completed</h6>
                  <h4 className="mb-0">${getTotalAmount('Completed').toLocaleString()}</h4>
                  <small>{getPaymentCount('Completed')} payments</small>
                </div>
                <div className="fs-1">✅</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-warning text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Pending</h6>
                  <h4 className="mb-0">${getTotalAmount('Pending').toLocaleString()}</h4>
                  <small>{getPaymentCount('Pending')} payments</small>
                </div>
                <div className="fs-1">⏳</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-danger text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Failed</h6>
                  <h4 className="mb-0">${getTotalAmount('Failed').toLocaleString()}</h4>
                  <small>{getPaymentCount('Failed')} payments</small>
                </div>
                <div className="fs-1">❌</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🔍 Filters</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4 mb-3">
              <label className="form-label">Search</label>
              <div className="input-group">
                <span className="input-group-text">🔍</span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search payments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Statuses</option>
                <option value="Completed">Completed</option>
                <option value="Pending">Pending</option>
                <option value="Failed">Failed</option>
              </select>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Payment Method</label>
              <select
                className="form-select"
                value={filterMethod}
                onChange={(e) => setFilterMethod(e.target.value)}
              >
                <option value="all">All Methods</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Check">Check</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Cash">Cash</option>
              </select>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Actions</label>
              <div className="d-grid">
                <button className="btn btn-outline-secondary" onClick={exportPayments}>
                  <span className="me-2">📥</span>Export
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payments Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Payments</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Payment</th>
                  <th>Order</th>
                  <th>Supplier</th>
                  <th>Amount</th>
                  <th>Payment Date</th>
                  <th>Due Date</th>
                  <th>Method</th>
                  <th>Status</th>
                  <th>Reference</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentPayments.map((payment) => (
                  <tr key={payment.id}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                             style={{ width: '40px', height: '40px', fontSize: '16px' }}>
                          💰
                        </div>
                        <div>
                          <strong>{payment.paymentNumber}</strong>
                          <br />
                          <small className="text-muted">{payment.description}</small>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge bg-secondary">{payment.orderNumber}</span>
                    </td>
                    <td>
                      <strong>{payment.supplierName}</strong>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">💵</span>
                        <strong>${payment.amount.toLocaleString()}</strong>
                        <br />
                        <small className="text-muted">{payment.currency}</small>
                      </div>
                    </td>
                    <td>
                      <small className="text-muted">{payment.paymentDate}</small>
                    </td>
                    <td>
                      <small className="text-muted">{payment.dueDate}</small>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">{getMethodIcon(payment.paymentMethod)}</span>
                        <span>{payment.paymentMethod}</span>
                      </div>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">{getStatusIcon(payment.status)}</span>
                        <span className={`badge bg-${getStatusColor(payment.status)}`}>
                          {payment.status}
                        </span>
                      </div>
                    </td>
                    <td>
                      <small className="text-muted">{payment.reference}</small>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button className="btn btn-outline-primary btn-sm" title="View Details">
                          👁️
                        </button>
                        <button className="btn btn-outline-warning btn-sm" title="Edit">
                          ✏️
                        </button>
                        <button className="btn btn-outline-danger btn-sm" title="Delete">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Empty State */}
      {filteredPayments.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No payments found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Payment Status Legend */}
      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h6 className="mb-0">📊 Payment Status Legend</h6>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-3 text-center">
                  <div className="text-success">
                    <div className="fs-1">✅</div>
                    <h6>Completed</h6>
                    <p className="text-muted">Payment successfully processed</p>
                  </div>
                </div>
                <div className="col-md-3 text-center">
                  <div className="text-warning">
                    <div className="fs-1">⏳</div>
                    <h6>Pending</h6>
                    <p className="text-muted">Payment is being processed</p>
                  </div>
                </div>
                <div className="col-md-3 text-center">
                  <div className="text-danger">
                    <div className="fs-1">❌</div>
                    <h6>Failed</h6>
                    <p className="text-muted">Payment processing failed</p>
                  </div>
                </div>
                <div className="col-md-3 text-center">
                  <div className="text-info">
                    <div className="fs-1">💰</div>
                    <h6>Processing</h6>
                    <p className="text-muted">Payment is being verified</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payments;
