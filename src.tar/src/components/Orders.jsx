import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [ordersPerPage] = useState(10);

  const [formData, setFormData] = useState({
    orderNumber: '',
    supplierId: '',
    orderDate: '',
    expectedDeliveryDate: '',
    totalAmount: 0,
    status: 'Pending',
    priority: 'Medium',
    notes: '',
    items: []
  });

  const orderStatuses = [
    { value: 'Pending', label: 'Pending', color: 'warning', icon: '⏳' },
    { value: 'Confirmed', label: 'Confirmed', color: 'info', icon: '✅' },
    { value: 'Processing', label: 'Processing', color: 'primary', icon: '⚙️' },
    { value: 'Shipped', label: 'Shipped', color: 'secondary', icon: '🚚' },
    { value: 'Delivered', label: 'Delivered', color: 'success', icon: '📦' },
    { value: 'Cancelled', label: 'Cancelled', color: 'danger', icon: '❌' }
  ];

  const orderPriorities = [
    { value: 'Low', label: 'Low', color: 'success', icon: '🟢' },
    { value: 'Medium', label: 'Medium', color: 'warning', icon: '🟡' },
    { value: 'High', label: 'High', color: 'danger', icon: '🔴' },
    { value: 'Urgent', label: 'Urgent', color: 'danger', icon: '🚨' }
  ];

  const orderSteps = [
    'Order Created',
    'Supplier Confirmed',
    'Processing',
    'Shipped',
    'Delivered'
  ];

  useEffect(() => {
    fetchOrders();
    fetchSuppliers();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      // Mock data since we don't have orders endpoint yet
      const mockOrders = [
        {
          id: 1,
          orderNumber: 'ORD-2024-001',
          supplierId: 1,
          supplierName: 'ABC Supplies Ltd',
          orderDate: '2024-01-15',
          expectedDeliveryDate: '2024-01-25',
          totalAmount: 5000.00,
          status: 'Confirmed',
          priority: 'Medium',
          notes: 'Office supplies and equipment',
          items: [
            { name: 'Office Chair', quantity: 10, unitPrice: 150.00 },
            { name: 'Desk Lamp', quantity: 20, unitPrice: 25.00 }
          ]
        },
        {
          id: 2,
          orderNumber: 'ORD-2024-002',
          supplierId: 2,
          supplierName: 'Tech Solutions Inc',
          orderDate: '2024-01-16',
          expectedDeliveryDate: '2024-01-30',
          totalAmount: 12000.00,
          status: 'Processing',
          priority: 'High',
          notes: 'Software licenses and maintenance',
          items: [
            { name: 'Office 365 License', quantity: 50, unitPrice: 240.00 }
          ]
        },
        {
          id: 3,
          orderNumber: 'ORD-2024-003',
          supplierId: 3,
          supplierName: 'Office Furniture Co',
          orderDate: '2024-01-17',
          expectedDeliveryDate: '2024-01-27',
          totalAmount: 8500.00,
          status: 'Shipped',
          priority: 'Medium',
          notes: 'Conference room furniture',
          items: [
            { name: 'Conference Table', quantity: 2, unitPrice: 2500.00 },
            { name: 'Conference Chairs', quantity: 20, unitPrice: 175.00 }
          ]
        }
      ];
      setOrders(mockOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      displayAlert('Error fetching orders', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const fetchSuppliers = async () => {
    try {
      // Mock suppliers data
      const mockSuppliers = [
        { id: 1, name: 'ABC Supplies Ltd', email: 'contact@abcsupplies.com', phone: '+1-555-0101' },
        { id: 2, name: 'Tech Solutions Inc', email: 'info@techsolutions.com', phone: '+1-555-0102' },
        { id: 3, name: 'Office Furniture Co', email: 'sales@officefurniture.com', phone: '+1-555-0103' }
      ];
      setSuppliers(mockSuppliers);
    } catch (error) {
      console.error('Error fetching suppliers:', error);
    }
  };

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  const handleOpenDialog = (order = null) => {
    if (order) {
      setEditingOrder(order);
      setFormData({
        orderNumber: order.orderNumber || '',
        supplierId: order.supplierId || '',
        orderDate: order.orderDate || '',
        expectedDeliveryDate: order.expectedDeliveryDate || '',
        totalAmount: order.totalAmount || 0,
        status: order.status || 'Pending',
        priority: order.priority || 'Medium',
        notes: order.notes || '',
        items: order.items || []
      });
    } else {
      setEditingOrder(null);
      setFormData({
        orderNumber: `ORD-${Date.now()}`,
        supplierId: '',
        orderDate: '',
        expectedDeliveryDate: '',
        totalAmount: 0,
        status: 'Pending',
        priority: 'Medium',
        notes: '',
        items: []
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingOrder(null);
    setFormData({
      orderNumber: '',
      supplierId: '',
      orderDate: '',
      expectedDeliveryDate: '',
      totalAmount: 0,
      status: 'Pending',
      priority: 'Medium',
      notes: '',
      items: []
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingOrder) {
        // Update existing order
        const updatedOrders = orders.map(order =>
          order.id === editingOrder.id
            ? { ...order, ...formData, supplierName: suppliers.find(s => s.id == formData.supplierId)?.name }
            : order
        );
        setOrders(updatedOrders);
        displayAlert('Order updated successfully', 'success');
      } else {
        // Add new order
        const newOrder = {
          id: Date.now(),
          ...formData,
          supplierName: suppliers.find(s => s.id == formData.supplierId)?.name
        };
        setOrders([newOrder, ...orders]);
        displayAlert('Order created successfully', 'success');
      }
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving order:', error);
      displayAlert('Error saving order', 'danger');
    }
  };

  const handleDelete = async (orderId) => {
    if (window.confirm('Are you sure you want to delete this order?')) {
      try {
        const updatedOrders = orders.filter(order => order.id !== orderId);
        setOrders(updatedOrders);
        displayAlert('Order deleted successfully', 'success');
      } catch (error) {
        console.error('Error deleting order:', error);
        displayAlert('Error deleting order', 'danger');
      }
    }
  };

  const getStatusIcon = (status) => {
    const statusObj = orderStatuses.find(s => s.value === status);
    return statusObj ? statusObj.icon : '📋';
  };

  const getStatusColor = (status) => {
    const statusObj = orderStatuses.find(s => s.value === status);
    return statusObj ? statusObj.color : 'secondary';
  };

  const getPriorityIcon = (priority) => {
    const priorityObj = orderPriorities.find(p => p.value === priority);
    return priorityObj ? priorityObj.icon : '⚪';
  };

  const getPriorityColor = (priority) => {
    const priorityObj = orderPriorities.find(p => p.value === priority);
    return priorityObj ? priorityObj.color : 'secondary';
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.notes.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || order.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || order.priority === filterPriority;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  // Pagination
  const indexOfLastOrder = currentPage * ordersPerPage;
  const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
  const currentOrders = filteredOrders.slice(indexOfFirstOrder, indexOfLastOrder);
  const totalPages = Math.ceil(filteredOrders.length / ordersPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const exportOrders = () => {
    displayAlert('Export functionality coming soon!', 'info');
  };

  const getTotalAmount = (status = null) => {
    const ordersToSum = status ? orders.filter(o => o.status === status) : orders;
    return ordersToSum.reduce((sum, order) => sum + order.totalAmount, 0);
  };

  const getOrderCount = (status = null) => {
    return status ? orders.filter(o => o.status === status).length : orders.length;
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="orders-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">📋 Orders Management</h2>
              <p className="text-muted mb-0">Track and manage purchase orders</p>
            </div>
            <div className="btn-group">
              <button className="btn btn-outline-secondary" onClick={fetchOrders}>
                <span className="me-2">🔄</span>Refresh
              </button>
              <button className="btn btn-primary" onClick={() => handleOpenDialog()}>
                <span className="me-2">➕</span>New Order
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Orders</h6>
                  <h4 className="mb-0">{getOrderCount()}</h4>
                  <small>${getTotalAmount().toLocaleString()}</small>
                </div>
                <div className="fs-1">📋</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-warning text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Pending</h6>
                  <h4 className="mb-0">{getOrderCount('Pending')}</h4>
                  <small>${getTotalAmount('Pending').toLocaleString()}</small>
                </div>
                <div className="fs-1">⏳</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-info text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Processing</h6>
                  <h4 className="mb-0">{getOrderCount('Processing')}</h4>
                  <small>${getTotalAmount('Processing').toLocaleString()}</small>
                </div>
                <div className="fs-1">⚙️</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Delivered</h6>
                  <h4 className="mb-0">{getOrderCount('Delivered')}</h4>
                  <small>${getTotalAmount('Delivered').toLocaleString()}</small>
                </div>
                <div className="fs-1">📦</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🔍 Filters</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4 mb-3">
              <label className="form-label">Search</label>
              <div className="input-group">
                <span className="input-group-text">🔍</span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Statuses</option>
                {orderStatuses.map(status => (
                  <option key={status.value} value={status.value}>{status.label}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Priority</label>
              <select
                className="form-select"
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
              >
                <option value="all">All Priorities</option>
                {orderPriorities.map(priority => (
                  <option key={priority.value} value={priority.value}>{priority.label}</option>
                ))}
              </select>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Actions</label>
              <div className="d-grid">
                <button className="btn btn-outline-secondary" onClick={exportOrders}>
                  <span className="me-2">📥</span>Export
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Orders</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Order</th>
                  <th>Supplier</th>
                  <th>Order Date</th>
                  <th>Expected Delivery</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Priority</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentOrders.map((order) => (
                  <tr key={order.id}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                             style={{ width: '40px', height: '40px', fontSize: '16px' }}>
                          📋
                        </div>
                        <div>
                          <strong>{order.orderNumber}</strong>
                          <br />
                          <small className="text-muted">{order.notes}</small>
                        </div>
                      </div>
                    </td>
                    <td>
                      <strong>{order.supplierName}</strong>
                    </td>
                    <td>
                      <small className="text-muted">{order.orderDate}</small>
                    </td>
                    <td>
                      <small className="text-muted">{order.expectedDeliveryDate}</small>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">💵</span>
                        <strong>${order.totalAmount.toLocaleString()}</strong>
                      </div>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">{getStatusIcon(order.status)}</span>
                        <span className={`badge bg-${getStatusColor(order.status)}`}>
                          {order.status}
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">{getPriorityIcon(order.priority)}</span>
                        <span className={`badge bg-${getPriorityColor(order.priority)}`}>
                          {order.priority}
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button className="btn btn-outline-primary btn-sm" title="View Details">
                          👁️
                        </button>
                        <button className="btn btn-outline-warning btn-sm" onClick={() => handleOpenDialog(order)} title="Edit">
                          ✏️
                        </button>
                        <button className="btn btn-outline-danger btn-sm" onClick={() => handleDelete(order.id)} title="Delete">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Empty State */}
      {filteredOrders.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No orders found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Order Status Steps */}
      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h6 className="mb-0">📊 Order Status Flow</h6>
            </div>
            <div className="card-body">
              <div className="row">
                {orderSteps.map((step, index) => (
                  <div key={index} className="col-md-2 text-center">
                    <div className="text-primary">
                      <div className="fs-1">{index + 1}</div>
                      <h6>{step}</h6>
                      <p className="text-muted">Step {index + 1}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Order Modal */}
      {openDialog && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  {editingOrder ? '✏️ Edit Order' : '➕ New Order'}
                </h5>
                <button type="button" className="btn-close" onClick={handleCloseDialog}></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Order Number</label>
                      <input
                        type="text"
                        className="form-control"
                        name="orderNumber"
                        value={formData.orderNumber}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Supplier</label>
                      <select
                        className="form-select"
                        name="supplierId"
                        value={formData.supplierId}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="">Select Supplier</option>
                        {suppliers.map(supplier => (
                          <option key={supplier.id} value={supplier.id}>{supplier.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Order Date</label>
                      <input
                        type="date"
                        className="form-control"
                        name="orderDate"
                        value={formData.orderDate}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Expected Delivery Date</label>
                      <input
                        type="date"
                        className="form-control"
                        name="expectedDeliveryDate"
                        value={formData.expectedDeliveryDate}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Total Amount</label>
                      <div className="input-group">
                        <span className="input-group-text">$</span>
                        <input
                          type="number"
                          className="form-control"
                          name="totalAmount"
                          value={formData.totalAmount}
                          onChange={handleInputChange}
                          step="0.01"
                          min="0"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Status</label>
                      <select
                        className="form-select"
                        name="status"
                        value={formData.status}
                        onChange={handleInputChange}
                        required
                      >
                        {orderStatuses.map(status => (
                          <option key={status.value} value={status.value}>{status.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Priority</label>
                      <select
                        className="form-select"
                        name="priority"
                        value={formData.priority}
                        onChange={handleInputChange}
                        required
                      >
                        {orderPriorities.map(priority => (
                          <option key={priority.value} value={priority.value}>{priority.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      rows="3"
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={handleCloseDialog}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    {editingOrder ? 'Update Order' : 'Create Order'}
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  );
};

export default Orders;
