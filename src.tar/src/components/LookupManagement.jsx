import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";

const LookupManagement = () => {
  const { t } = useTranslation();
  const [openDialog, setOpenDialog] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [currencies, setCurrencies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'categories',
    status: 'active',
    color: '#3b82f6',
    category: '',
    rating: 5,
    usage: 0
  });

  // Sample data for lookup tables
  const [lookupData, setLookupData] = useState({
    categories: [
      { id: 1, name: 'Electronics', description: 'Electronic devices and accessories', status: 'active', count: 156 },
      { id: 2, name: 'Clothing', description: 'Apparel and fashion items', status: 'active', count: 89 },
      { id: 3, name: 'Home & Garden', description: 'Home improvement and garden supplies', status: 'active', count: 234 },
      { id: 4, name: 'Sports', description: 'Sports equipment and accessories', status: 'inactive', count: 67 }
    ],
    suppliers: [
      { id: 1, name: 'TechCorp Inc.', category: 'Electronics', status: 'active', rating: 4.5 },
      { id: 2, name: 'Fashion Plus', category: 'Clothing', status: 'active', rating: 4.2 },
      { id: 3, name: 'Home Solutions', category: 'Home & Garden', status: 'active', rating: 4.7 }
    ],
    tags: [
      { id: 1, name: 'Premium', color: '#10b981', usage: 45 },
      { id: 2, name: 'Sale', color: '#f59e0b', usage: 23 },
      { id: 3, name: 'New', color: '#3b82f6', usage: 67 },
      { id: 4, name: 'Limited', color: '#ef4444', usage: 12 }
    ],
    currencies: []
  });

  // Fetch currencies from API gateway
  useEffect(() => {
    fetchCurrencies();
  }, []);

  const fetchCurrencies = async () => {
    setLoading(true);
    try {
      // Replace with your actual API gateway endpoint
      const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      const data = await response.json();
      
      if (data.rates) {
        const currencyList = Object.keys(data.rates).map(code => ({
          id: code,
          name: code,
          description: `${code} - ${code === 'USD' ? 'US Dollar' : code === 'EUR' ? 'Euro' : code === 'GBP' ? 'British Pound' : code}`,
          status: 'active',
          rate: data.rates[code],
          lastUpdated: new Date().toISOString()
        }));
        
        setLookupData(prev => ({
          ...prev,
          currencies: currencyList
        }));
        setCurrencies(currencyList);
      }
    } catch (error) {
      console.error('Error fetching currencies:', error);
      // Fallback to sample currency data
      const sampleCurrencies = [
        { id: 'USD', name: 'USD', description: 'US Dollar', status: 'active', rate: 1.0, lastUpdated: new Date().toISOString() },
        { id: 'EUR', name: 'EUR', description: 'Euro', status: 'active', rate: 0.85, lastUpdated: new Date().toISOString() },
        { id: 'GBP', name: 'GBP', description: 'British Pound', status: 'active', rate: 0.73, lastUpdated: new Date().toISOString() },
        { id: 'JPY', name: 'JPY', description: 'Japanese Yen', status: 'active', rate: 110.0, lastUpdated: new Date().toISOString() }
      ];
      setLookupData(prev => ({
        ...prev,
        currencies: sampleCurrencies
      }));
      setCurrencies(sampleCurrencies);
    } finally {
      setLoading(false);
    }
  };

  const handleAddNew = () => {
    setEditMode(false);
    setSelectedItem(null);
    setFormData({
      name: '',
      description: '',
      type: 'categories',
      status: 'active',
      color: '#3b82f6',
      category: '',
      rating: 5,
      usage: 0
    });
    setOpenDialog(true);
  };

  const handleEdit = (item) => {
    setEditMode(true);
    setSelectedItem(item);
    setFormData({
      name: item.name || '',
      description: item.description || '',
      type: getItemType(item),
      status: item.status || 'active',
      color: item.color || '#3b82f6',
      category: item.category || '',
      rating: item.rating || 5,
      usage: item.usage || 0
    });
    setOpenDialog(true);
  };

  const getItemType = (item) => {
    if (item.count !== undefined) return 'categories';
    if (item.rating !== undefined) return 'suppliers';
    if (item.color !== undefined) return 'tags';
    if (item.rate !== undefined) return 'currencies';
    return 'categories';
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      // Handle delete logic here
      console.log('Delete item with id:', id);
      // Update the state to remove the item
      setLookupData(prev => ({
        categories: prev.categories.filter(item => item.id !== id),
        suppliers: prev.suppliers.filter(item => item.id !== id),
        tags: prev.tags.filter(item => item.id !== id),
        currencies: prev.currencies.filter(item => item.id !== id)
      }));
    }
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      alert('Name is required');
      return;
    }

    const newItem = {
      id: editMode ? selectedItem.id : Date.now(),
      name: formData.name,
      description: formData.description,
      status: formData.status,
      ...(formData.type === 'categories' && { count: 0 }),
      ...(formData.type === 'suppliers' && { category: formData.category, rating: formData.rating }),
      ...(formData.type === 'tags' && { color: formData.color, usage: formData.usage }),
      ...(formData.type === 'currencies' && { rate: 1.0, lastUpdated: new Date().toISOString() })
    };

    if (editMode) {
      // Update existing item
      setLookupData(prev => ({
        ...prev,
        [formData.type]: prev[formData.type].map(item => 
          item.id === selectedItem.id ? newItem : item
        )
      }));
    } else {
      // Add new item
      setLookupData(prev => ({
        ...prev,
        [formData.type]: [...prev[formData.type], newItem]
      }));
    }

    setOpenDialog(false);
    setSelectedItem(null);
  };

  const handleClose = () => {
    setOpenDialog(false);
    setSelectedItem(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const renderLookupTable = (data, type) => {
    const getColumns = () => {
      switch(type) {
        case 'categories':
          return [
            { field: 'name', header: 'Category Name' },
            { field: 'description', header: 'Description' },
            { field: 'status', header: 'Status' },
            { field: 'count', header: 'Items Count' },
            { field: 'actions', header: 'Actions' }
          ];
        case 'suppliers':
          return [
            { field: 'name', header: 'Supplier Name' },
            { field: 'category', header: 'Category' },
            { field: 'status', header: 'Status' },
            { field: 'rating', header: 'Rating' },
            { field: 'actions', header: 'Actions' }
          ];
        case 'tags':
          return [
            { field: 'name', header: 'Tag Name' },
            { field: 'color', header: 'Color' },
            { field: 'usage', header: 'Usage Count' },
            { field: 'actions', header: 'Actions' }
          ];
        case 'currencies':
          return [
            { field: 'name', header: 'Currency Code' },
            { field: 'description', header: 'Description' },
            { field: 'rate', header: 'Exchange Rate' },
            { field: 'status', header: 'Status' },
            { field: 'actions', header: 'Actions' }
          ];
        default:
          return [];
      }
    };

    const columns = getColumns();

    return (
      <div className="table-responsive">
        <table className="table table-hover border">
          <thead className="table-light">
            <tr>
              {columns.map((column) => (
                <th key={column.field} className="fw-semibold text-dark">
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row) => (
              <tr key={row.id}>
                <td>
                  <div className="d-flex align-items-center gap-3">
                    <div className="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold" style={{
                      width: '32px',
                      height: '32px',
                      background: type === 'tags' ? row.color : '#3b82f6',
                      fontSize: '0.875rem'
                    }}>
                      {type === 'categories' && '📁'}
                      {type === 'suppliers' && '🏢'}
                      {type === 'tags' && '🏷️'}
                      {type === 'currencies' && '💰'}
                    </div>
                    <span className="fw-medium">
                      {row.name}
                    </span>
                  </div>
                </td>
                
                {type === 'categories' && (
                  <>
                    <td>{row.description}</td>
                    <td>
                      <span className={`badge ${
                        row.status === 'active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                    <td>{row.count}</td>
                  </>
                )}
                
                {type === 'suppliers' && (
                  <>
                    <td>{row.category}</td>
                    <td>
                      <span className={`badge ${
                        row.status === 'active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <span className="fw-medium">{row.rating}</span>
                        <span className="text-muted">/5</span>
                      </div>
                    </td>
                  </>
                )}
                
                {type === 'tags' && (
                  <>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <div className="rounded-circle" style={{ 
                          width: '20px', 
                          height: '20px', 
                          background: row.color 
                        }} />
                        <span className="text-muted">{row.color}</span>
                      </div>
                    </td>
                    <td>{row.usage}</td>
                  </>
                )}

                {type === 'currencies' && (
                  <>
                    <td>{row.description}</td>
                    <td>
                      <span className="fw-medium">
                        {row.rate ? row.rate.toFixed(4) : 'N/A'}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${
                        row.status === 'active' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                  </>
                )}
                
                <td>
                  <div className="d-flex gap-2">
                    <button 
                      className="btn btn-sm btn-outline-primary"
                      onClick={() => handleEdit(row)}
                    >
                      ✏️
                    </button>
                    <button 
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => handleDelete(row.id)}
                    >
                      🗑️
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="w-100" style={{ 
      minHeight: '100%',
      background: '#f8fafc',
      padding: 0,
      margin: 0,
      boxSizing: 'border-box'
    }}>
      {/* Header */}
      <div className="w-100 bg-white border-bottom border-light p-4 mb-0">
        <div className="d-flex justify-content-between align-items-center w-100">
          <div>
            <h2 className="h3 fw-bold text-dark mb-2">
              Lookup Management
            </h2>
            <p className="text-muted mb-0">
              Manage categories, suppliers, tags, currencies, and other reference data
            </p>
          </div>
          <button
            className="btn btn-primary d-flex align-items-center gap-2"
            onClick={handleAddNew}
          >
            <span>➕</span>
            Add New
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="w-100 p-4" style={{ boxSizing: 'border-box' }}>
        {/* Search and Filter Bar */}
        <div className="card border-light shadow-sm mb-4">
          <div className="card-body p-4">
            <div className="row g-3 align-items-center">
              <div className="col-12 col-md-6">
                <div className="input-group">
                  <span className="input-group-text bg-light border-end-0">
                    🔍
                  </span>
                  <input
                    type="text"
                    className="form-control border-start-0"
                    placeholder="Search lookups..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="col-12 col-md-3">
                <select
                  className="form-select"
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                >
                  <option value="all">All Types</option>
                  <option value="categories">Categories</option>
                  <option value="suppliers">Suppliers</option>
                  <option value="tags">Tags</option>
                  <option value="currencies">Currencies</option>
                </select>
              </div>
              <div className="col-12 col-md-3">
                <button className="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-2">
                  <span>🔧</span>
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Lookup Tables */}
        <div className="row g-4">
          {/* Categories */}
          <div className="col-12">
            <div className="card border-light shadow-sm">
              <div className="card-header bg-light border-bottom-0">
                <h6 className="fw-semibold text-dark mb-0">
                  Categories
                </h6>
              </div>
              {renderLookupTable(lookupData.categories, 'categories')}
            </div>
          </div>

          {/* Suppliers */}
          <div className="col-12">
            <div className="card border-light shadow-sm">
              <div className="card-header bg-light border-bottom-0">
                <h6 className="fw-semibold text-dark mb-0">
                  Suppliers
                </h6>
              </div>
              {renderLookupTable(lookupData.suppliers, 'suppliers')}
            </div>
          </div>

          {/* Tags */}
          <div className="col-12">
            <div className="card border-light shadow-sm">
              <div className="card-header bg-light border-bottom-0">
                <h6 className="fw-semibold text-dark mb-0">
                  Tags
                </h6>
              </div>
              {renderLookupTable(lookupData.tags, 'tags')}
            </div>
          </div>

          {/* Currencies */}
          <div className="col-12">
            <div className="card border-light shadow-sm">
              <div className="card-header bg-light border-bottom-0 d-flex justify-content-between align-items-center">
                <h6 className="fw-semibold text-dark mb-0">
                  Currencies
                </h6>
                <button 
                  className="btn btn-sm btn-outline-primary"
                  onClick={fetchCurrencies}
                  disabled={loading}
                >
                  {loading ? (
                    <span className="spinner-border spinner-border-sm me-2" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </span>
                  ) : (
                    <span>🔄</span>
                  )}
                  Refresh Rates
                </button>
              </div>
              {renderLookupTable(lookupData.currencies, 'currencies')}
            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {openDialog && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header bg-light">
                <h5 className="modal-title fw-semibold">
                  {editMode ? 'Edit Lookup Item' : 'Add New Lookup Item'}
                </h5>
                <button type="button" className="btn-close" onClick={handleClose}></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label fw-medium">Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Enter name"
                      required
                    />
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-medium">Description</label>
                    <textarea
                      className="form-control"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      rows="3"
                      placeholder="Enter description"
                    />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label fw-medium">Type</label>
                    <select
                      className="form-select"
                      name="type"
                      value={formData.type}
                      onChange={handleInputChange}
                    >
                      <option value="categories">Categories</option>
                      <option value="suppliers">Suppliers</option>
                      <option value="tags">Tags</option>
                      <option value="currencies">Currencies</option>
                    </select>
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label fw-medium">Status</label>
                    <select
                      className="form-select"
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                    >
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </div>
                  
                  {formData.type === 'suppliers' && (
                    <>
                      <div className="col-12 col-md-6">
                        <label className="form-label fw-medium">Category</label>
                        <input
                          type="text"
                          className="form-control"
                          name="category"
                          value={formData.category}
                          onChange={handleInputChange}
                          placeholder="Enter category"
                        />
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="form-label fw-medium">Rating</label>
                        <input
                          type="number"
                          className="form-control"
                          name="rating"
                          value={formData.rating}
                          onChange={handleInputChange}
                          min="1"
                          max="5"
                          step="0.1"
                        />
                      </div>
                    </>
                  )}
                  
                  {formData.type === 'tags' && (
                    <>
                      <div className="col-12 col-md-6">
                        <label className="form-label fw-medium">Color</label>
                        <input
                          type="color"
                          className="form-control form-control-color"
                          name="color"
                          value={formData.color}
                          onChange={handleInputChange}
                        />
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="form-label fw-medium">Usage Count</label>
                        <input
                          type="number"
                          className="form-control"
                          name="usage"
                          value={formData.usage}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>
              <div className="modal-footer bg-light">
                <button type="button" className="btn btn-secondary" onClick={handleClose}>
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-primary d-flex align-items-center gap-2"
                  onClick={handleSave}
                >
                  <span>💾</span>
                  {editMode ? 'Update' : 'Create'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LookupManagement; 