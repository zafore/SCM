import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import '../styles/design-system.css';

const Dashboard = () => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 1500);
    
    // Update time every second
    const timeTimer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    return () => {
      clearTimeout(timer);
      clearInterval(timeTimer);
    };
  }, []);

  const statsData = [
    {
      title: 'Total Revenue',
      value: '$2,847,392',
      change: '+12.5%',
      trend: 'up',
      description: 'Monthly growth',
      bgColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      icon: '💰',
      details: 'From $2,531,904 last month'
    },
    {
      title: 'Active Orders',
      value: '1,247',
      change: '+8.2%',
      trend: 'up',
      description: 'Currently processing',
      bgColor: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      icon: '📦',
      details: '23 orders completed today'
    },
    {
      title: 'Inventory Items',
      value: '8,392',
      change: '-2.1%',
      trend: 'down',
      description: 'In stock',
      bgColor: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      icon: '🏪',
      details: '156 items low on stock'
    },
    {
      title: 'Active Suppliers',
      value: '342',
      change: '+5.7%',
      trend: 'up',
      description: 'Partnerships',
      bgColor: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
      icon: '🤝',
      details: '12 new suppliers this month'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'order',
      message: 'New order #ORD-2024-001 received',
      time: '2 minutes ago',
      user: 'John Smith',
      icon: '📋',
      priority: 'high'
    },
    {
      id: 2,
      type: 'payment',
      message: 'Payment received for invoice #INV-2024-089',
      time: '15 minutes ago',
      user: 'TechCorp Inc.',
      icon: '💳',
      priority: 'medium'
    },
    {
      id: 3,
      type: 'inventory',
      message: 'Low stock alert: Product XYZ-123',
      time: '1 hour ago',
      user: 'System',
      icon: '⚠️',
      priority: 'critical'
    },
    {
      id: 4,
      type: 'supplier',
      message: 'New supplier contract signed',
      time: '2 hours ago',
      user: 'Sarah Johnson',
      icon: '✍️',
      priority: 'medium'
    },
    {
      id: 5,
      type: 'audit',
      message: 'Monthly audit completed',
      time: '4 hours ago',
      user: 'Audit Team',
      icon: '🔍',
      priority: 'low'
    }
  ];

  const quickActions = [
    { name: 'Create Order', icon: '📋', color: 'primary', action: () => console.log('Create Order') },
    { name: 'Add Supplier', icon: '🤝', color: 'success', action: () => console.log('Add Supplier') },
    { name: 'Update Inventory', icon: '🏪', color: 'warning', action: () => console.log('Update Inventory') },
    { name: 'Generate Report', icon: '📊', color: 'info', action: () => console.log('Generate Report') },
    { name: 'Process Payment', icon: '💳', color: 'danger', action: () => console.log('Process Payment') },
    { name: 'View Analytics', icon: '📈', color: 'secondary', action: () => console.log('View Analytics') }
  ];

  const systemMetrics = [
    { name: 'CPU Usage', value: 68, max: 100, color: 'primary', status: 'normal' },
    { name: 'Memory Usage', value: 82, max: 100, color: 'warning', status: 'warning' },
    { name: 'Disk Space', value: 45, max: 100, color: 'success', status: 'normal' },
    { name: 'Network Load', value: 73, max: 100, color: 'info', status: 'normal' }
  ];

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'success';
      case 'critical': return 'danger';
      default: return 'secondary';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'normal': return 'success';
      case 'warning': return 'warning';
      case 'critical': return 'danger';
      default: return 'secondary';
    }
  };

  if (loading) {
    return (
      <div className="dashboard-container fade-in-up">
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-3 text-muted">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-container fade-in-up">
      {/* Enhanced Header with Live Time */}
      <div className="dashboard-header card-enhanced mb-4">
        <div className="row align-items-center">
          <div className="col-md-8">
            <h1 className="display-6 mb-2 text-primary fw-bold">
              Welcome back, Administrator! 👋
            </h1>
            <p className="lead mb-0 text-muted">
              Here's what's happening with your supply chain today
            </p>
          </div>
          <div className="col-md-4 text-md-end">
            <div className="current-time">
              <div className="time-display h3 text-primary mb-1">
                {currentTime.toLocaleTimeString()}
              </div>
              <div className="date-display text-muted">
                {currentTime.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Stats Cards */}
      <div className="row g-4 mb-4">
        {statsData.map((stat, index) => (
          <div key={index} className="col-xl-3 col-md-6">
            <div className="card-enhanced h-100 stats-card">
              <div className="card-body p-4">
                <div className="d-flex justify-content-between align-items-start mb-3">
                  <div className="stats-icon" style={{ fontSize: '2.5rem' }}>
                    {stat.icon}
                  </div>
                  <div className="dropdown">
                    <button className="btn btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                      <i className="bi bi-three-dots-vertical"></i>
                    </button>
                    <ul className="dropdown-menu">
                      <li><a className="dropdown-item" href="#"><i className="bi bi-eye me-2"></i>View Details</a></li>
                      <li><a className="dropdown-item" href="#"><i className="bi bi-graph-up me-2"></i>Analytics</a></li>
                      <li><a className="dropdown-item" href="#"><i className="bi bi-download me-2"></i>Export</a></li>
                    </ul>
                  </div>
                </div>
                <h3 className="h2 mb-2 fw-bold" style={{ background: stat.bgColor, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  {stat.value}
                </h3>
                <p className="text-muted mb-2">{stat.description}</p>
                <div className="d-flex align-items-center">
                  <span className={`trend-indicator ${stat.trend} me-2`}>
                    {stat.trend === 'up' ? '↗️' : '↘️'}
                  </span>
                  <span className={`badge badge-${stat.trend === 'up' ? 'success' : 'danger'}-enhanced me-2`}>
                    {stat.change}
                  </span>
                  <small className="text-muted">{stat.details}</small>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="row g-4">
        {/* Recent Activities */}
        <div className="col-lg-8">
          <div className="card-enhanced h-100">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0 fw-bold">
                <i className="bi bi-activity me-2"></i>
                Recent Activities
              </h5>
              <div className="btn-group" role="group">
                <button type="button" className="btn btn-sm btn-outline-primary">Today</button>
                <button type="button" className="btn btn-sm btn-outline-primary active">Week</button>
                <button type="button" className="btn btn-sm btn-outline-primary">Month</button>
              </div>
            </div>
            <div className="card-body p-0">
              <div className="activity-list p-3">
                {recentActivities.map((activity, index) => (
                  <div key={activity.id} className="activity-item d-flex align-items-center py-3 border-bottom border-light">
                    <div className="activity-icon me-3" style={{ fontSize: '1.5rem' }}>
                      {activity.icon}
                    </div>
                    <div className="activity-details flex-grow-1">
                      <div className="d-flex justify-content-between align-items-start">
                        <div>
                          <p className="mb-1 fw-semibold">{activity.message}</p>
                          <small className="text-muted">
                            <i className="bi bi-person me-1"></i>
                            {activity.user} • {activity.time}
                          </small>
                        </div>
                        <span className={`badge badge-${getPriorityColor(activity.priority)}-enhanced`}>
                          {activity.priority}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card-footer text-center">
              <a href="#" className="btn btn-link text-primary">
                View All Activities <i className="bi bi-arrow-right ms-1"></i>
              </a>
            </div>
          </div>
        </div>

        {/* Quick Actions & System Metrics */}
        <div className="col-lg-4">
          {/* Quick Actions */}
          <div className="card-enhanced mb-4">
            <div className="card-header">
              <h6 className="mb-0 fw-bold">
                <i className="bi bi-lightning me-2"></i>
                Quick Actions
              </h6>
            </div>
            <div className="card-body">
              <div className="row g-2">
                {quickActions.map((action, index) => (
                  <div key={index} className="col-6">
                    <button 
                      className={`btn btn-${action.color}-enhanced w-100 btn-sm`}
                      onClick={action.action}
                      style={{ height: '60px' }}
                    >
                      <div className="d-flex flex-column align-items-center">
                        <span style={{ fontSize: '1.5rem' }}>{action.icon}</span>
                        <small className="mt-1">{action.name}</small>
                      </div>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* System Metrics */}
          <div className="card-enhanced">
            <div className="card-header">
              <h6 className="mb-0 fw-bold">
                <i className="bi bi-cpu me-2"></i>
                System Health
              </h6>
            </div>
            <div className="card-body">
              <div className="metrics-list">
                {systemMetrics.map((metric, index) => (
                  <div key={index} className="metric-item d-flex justify-content-between align-items-center mb-3">
                    <div className="d-flex align-items-center">
                      <span className={`status-dot ${getStatusColor(metric.status)} me-2`}></span>
                      <span className="fw-medium">{metric.name}</span>
                    </div>
                    <div className="text-end">
                      <div className="fw-bold">{metric.value}%</div>
                      <div className="progress" style={{ width: '60px', height: '6px' }}>
                        <div 
                          className={`progress-bar bg-${metric.color}`} 
                          style={{ width: `${metric.value}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Footer with Additional Info */}
      <div className="dashboard-footer mt-4">
        <div className="card-enhanced">
          <div className="card-body text-center py-4">
            <div className="row align-items-center">
              <div className="col-md-4">
                <div className="system-status p-3">
                  <h6 className="mb-2">System Status</h6>
                  <div className="d-flex justify-content-center">
                    <span className="status-indicator active me-2"></span>
                    <span className="status-indicator normal me-2"></span>
                    <span className="status-indicator warning me-2"></span>
                    <span className="status-indicator critical"></span>
                  </div>
                  <small className="text-muted">All systems operational</small>
                </div>
              </div>
              <div className="col-md-4">
                <div className="text-center">
                  <h6 className="mb-2">Last Backup</h6>
                  <p className="mb-1 fw-bold text-success">2 hours ago</p>
                  <small className="text-muted">Next backup in 22 hours</small>
                </div>
              </div>
              <div className="col-md-4">
                <div className="text-center">
                  <h6 className="mb-2">Uptime</h6>
                  <p className="mb-1 fw-bold text-primary">99.97%</p>
                  <small className="text-muted">Last 30 days</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;