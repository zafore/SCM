import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const Contracts = () => {
  const { t } = useTranslation();
  const [contracts, setContracts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingContract, setEditingContract] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedContract, setSelectedContract] = useState(null);
  const [formData, setFormData] = useState({
    contractNumber: '',
    supplierId: '',
    title: '',
    description: '',
    startDate: '',
    endDate: '',
    totalValue: 0,
    status: 'Draft',
    contractType: 'Service',
    terms: '',
    renewalTerms: '',
    notes: ''
  });

  const contractStatuses = [
    { value: 'Draft', label: 'Draft', color: 'secondary' },
    { value: 'Active', label: 'Active', color: 'success' },
    { value: 'Expired', label: 'Expired', color: 'danger' },
    { value: 'Terminated', label: 'Terminated', color: 'warning' },
    { value: 'Under Review', label: 'Under Review', color: 'info' }
  ];

  const contractTypes = [
    'Service',
    'Supply',
    'Maintenance',
    'Consulting',
    'Software License',
    'Equipment Lease'
  ];

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  useEffect(() => {
    fetchContracts();
    fetchSuppliers();
  }, []);

  const fetchContracts = async () => {
    try {
      setLoading(true);
      // Since we don't have a contracts endpoint yet, we'll simulate data
      const mockContracts = [
        {
          id: 1,
          contractNumber: 'CNT-2024-001',
          supplierName: 'ABC Supplies Ltd',
          title: 'Office Supplies Contract',
          startDate: '2024-01-01',
          endDate: '2024-12-31',
          totalValue: 50000,
          status: 'Active',
          contractType: 'Supply',
          description: 'Annual contract for office supplies and stationery',
          terms: 'Net 30 days payment terms',
          renewalTerms: 'Auto-renewal with 30 days notice'
        },
        {
          id: 2,
          contractNumber: 'CNT-2024-002',
          supplierName: 'Tech Solutions Inc',
          title: 'IT Services Agreement',
          startDate: '2024-02-01',
          endDate: '2025-01-31',
          totalValue: 120000,
          status: 'Active',
          contractType: 'Service',
          description: 'Comprehensive IT support and maintenance services',
          terms: 'Monthly invoicing, Net 45 days',
          renewalTerms: 'Renewal option with price adjustment'
        },
        {
          id: 3,
          contractNumber: 'CNT-2024-003',
          supplierName: 'Maintenance Pro',
          title: 'Building Maintenance Contract',
          startDate: '2023-06-01',
          endDate: '2024-05-31',
          totalValue: 75000,
          status: 'Expired',
          contractType: 'Maintenance',
          description: 'Building maintenance and cleaning services',
          terms: 'Quarterly payments',
          renewalTerms: 'Manual renewal required'
        }
      ];
      setContracts(mockContracts);
    } catch (error) {
      console.error('Error fetching contracts:', error);
      displayAlert('Error fetching contracts', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const fetchSuppliers = async () => {
    try {
      // Mock suppliers data
      const mockSuppliers = [
        { id: 1, name: 'ABC Supplies Ltd' },
        { id: 2, name: 'Tech Solutions Inc' },
        { id: 3, name: 'Maintenance Pro' },
        { id: 4, name: 'Consulting Experts' }
      ];
      setSuppliers(mockSuppliers);
    } catch (error) {
      console.error('Error fetching suppliers:', error);
    }
  };

  const handleOpenDialog = (contract = null) => {
    if (contract) {
      setEditingContract(contract);
      setFormData({
        contractNumber: contract.contractNumber || '',
        supplierId: contract.supplierId || '',
        title: contract.title || '',
        description: contract.description || '',
        startDate: contract.startDate || '',
        endDate: contract.endDate || '',
        totalValue: contract.totalValue || 0,
        status: contract.status || 'Draft',
        contractType: contract.contractType || 'Service',
        terms: contract.terms || '',
        renewalTerms: contract.renewalTerms || '',
        notes: contract.notes || ''
      });
    } else {
      setEditingContract(null);
      setFormData({
        contractNumber: `CNT-${Date.now()}`,
        supplierId: '',
        title: '',
        description: '',
        startDate: '',
        endDate: '',
        totalValue: 0,
        status: 'Draft',
        contractType: 'Service',
        terms: '',
        renewalTerms: '',
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingContract(null);
    setFormData({
      contractNumber: '',
      supplierId: '',
      title: '',
      description: '',
      startDate: '',
      endDate: '',
      totalValue: 0,
      status: 'Draft',
      contractType: 'Service',
      terms: '',
      renewalTerms: '',
      notes: ''
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingContract) {
        // Update existing contract
        const updatedContracts = contracts.map(contract =>
          contract.id === editingContract.id
            ? { ...contract, ...formData }
            : contract
        );
        setContracts(updatedContracts);
        displayAlert('Contract updated successfully', 'success');
      } else {
        // Add new contract
        const newContract = {
          id: Date.now(),
          ...formData,
          supplierName: suppliers.find(s => s.id == formData.supplierId)?.name || 'Unknown Supplier'
        };
        setContracts([newContract, ...contracts]);
        displayAlert('Contract created successfully', 'success');
      }
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving contract:', error);
      displayAlert('Error saving contract', 'danger');
    }
  };

  const handleDelete = async (contractId) => {
    if (window.confirm('Are you sure you want to delete this contract?')) {
      try {
        const updatedContracts = contracts.filter(contract => contract.id !== contractId);
        setContracts(updatedContracts);
        displayAlert('Contract deleted successfully', 'success');
      } catch (error) {
        console.error('Error deleting contract:', error);
        displayAlert('Error deleting contract', 'danger');
      }
    }
  };

  const handleViewDetails = (contract) => {
    setSelectedContract(contract);
  };

  const handleCloseModal = () => {
    setSelectedContract(null);
  };

  const getStatusBadgeClass = (status) => {
    const statusObj = contractStatuses.find(s => s.value === status);
    if (!statusObj) return 'badge bg-secondary';
    return `badge bg-${statusObj.color}`;
  };

  const filteredContracts = contracts.filter(contract => {
    const matchesSearch = contract.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contract.contractNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contract.supplierName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || contract.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const indexOfLastContract = currentPage * contractsPerPage;
  const indexOfFirstContract = indexOfLastContract - contractsPerPage;
  const currentContracts = filteredContracts.slice(indexOfFirstContract, indexOfLastContract);
  const totalPages = Math.ceil(filteredContracts.length / contractsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const exportContracts = () => {
    displayAlert('Export functionality coming soon!', 'info');
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="contracts-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">📋 Contracts Management</h2>
              <p className="text-muted mb-0">Manage supplier contracts and agreements</p>
            </div>
            <div className="btn-group">
              <button className="btn btn-outline-secondary" onClick={fetchContracts}>
                <span className="me-2">🔄</span>Refresh
              </button>
              <button className="btn btn-primary" onClick={() => handleOpenDialog()}>
                <span className="me-2">➕</span>New Contract
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Contracts</h6>
                  <h4 className="mb-0">{contracts.length}</h4>
                </div>
                <div className="fs-1">📋</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Active</h6>
                  <h4 className="mb-0">{contracts.filter(c => c.status === 'Active').length}</h4>
                </div>
                <div className="fs-1">✅</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-warning text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Expiring Soon</h6>
                  <h4 className="mb-0">{contracts.filter(c => {
                    const endDate = new Date(c.endDate);
                    const today = new Date();
                    const daysUntilExpiry = Math.ceil((endDate - today) / (1000 * 60 * 60 * 24));
                    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
                  }).length}</h4>
                </div>
                <div className="fs-1">⚠️</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-info text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Value</h6>
                  <h4 className="mb-0">${contracts.reduce((sum, c) => sum + c.totalValue, 0).toLocaleString()}</h4>
                </div>
                <div className="fs-1">💰</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🔍 Filters</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">Search</label>
              <div className="input-group">
                <span className="input-group-text">🔍</span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search contracts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Statuses</option>
                {contractStatuses.map(status => (
                  <option key={status.value} value={status.value}>{status.label}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Actions</label>
              <div className="d-grid">
                <button className="btn btn-outline-secondary" onClick={exportContracts}>
                  <span className="me-2">📥</span>Export
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contracts Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Contracts</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Contract #</th>
                  <th>Title</th>
                  <th>Supplier</th>
                  <th>Type</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Value</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentContracts.map((contract) => (
                  <tr key={contract.id}>
                    <td>
                      <strong>{contract.contractNumber}</strong>
                    </td>
                    <td>{contract.title}</td>
                    <td>{contract.supplierName}</td>
                    <td>
                      <span className="badge bg-secondary">{contract.contractType}</span>
                    </td>
                    <td>{contract.startDate}</td>
                    <td>{contract.endDate}</td>
                    <td>
                      <strong>${contract.totalValue.toLocaleString()}</strong>
                    </td>
                    <td>
                      <span className={getStatusBadgeClass(contract.status)}>
                        {contract.status}
                      </span>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button 
                          className="btn btn-outline-primary btn-sm" 
                          onClick={() => handleViewDetails(contract)}
                          title="View Details"
                        >
                          👁️
                        </button>
                        <button 
                          className="btn btn-outline-warning btn-sm" 
                          onClick={() => handleOpenDialog(contract)}
                          title="Edit"
                        >
                          ✏️
                        </button>
                        <button 
                          className="btn btn-outline-danger btn-sm" 
                          onClick={() => handleDelete(contract.id)}
                          title="Delete"
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Empty State */}
      {filteredContracts.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No contracts found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Add/Edit Contract Modal */}
      {openDialog && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  {editingContract ? '✏️ Edit Contract' : '➕ New Contract'}
                </h5>
                <button type="button" className="btn-close" onClick={handleCloseDialog}></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Contract Number</label>
                      <input
                        type="text"
                        className="form-control"
                        value={formData.contractNumber}
                        onChange={(e) => setFormData({...formData, contractNumber: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Supplier</label>
                      <select
                        className="form-select"
                        value={formData.supplierId}
                        onChange={(e) => setFormData({...formData, supplierId: e.target.value})}
                        required
                      >
                        <option value="">Select Supplier</option>
                        {suppliers.map(supplier => (
                          <option key={supplier.id} value={supplier.id}>{supplier.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Title</label>
                      <input
                        type="text"
                        className="form-control"
                        value={formData.title}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Contract Type</label>
                      <select
                        className="form-select"
                        value={formData.contractType}
                        onChange={(e) => setFormData({...formData, contractType: e.target.value})}
                        required
                      >
                        {contractTypes.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Start Date</label>
                      <input
                        type="date"
                        className="form-control"
                        value={formData.startDate}
                        onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">End Date</label>
                      <input
                        type="date"
                        className="form-control"
                        value={formData.endDate}
                        onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Total Value</label>
                      <div className="input-group">
                        <span className="input-group-text">$</span>
                        <input
                          type="number"
                          className="form-control"
                          value={formData.totalValue}
                          onChange={(e) => setFormData({...formData, totalValue: parseFloat(e.target.value) || 0})}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Status</label>
                      <select
                        className="form-select"
                        value={formData.status}
                        onChange={(e) => setFormData({...formData, status: e.target.value})}
                        required
                      >
                        {contractStatuses.map(status => (
                          <option key={status.value} value={status.value}>{status.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Description</label>
                    <textarea
                      className="form-control"
                      rows="3"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                    />
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Terms</label>
                      <textarea
                        className="form-control"
                        rows="2"
                        value={formData.terms}
                        onChange={(e) => setFormData({...formData, terms: e.target.value})}
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Renewal Terms</label>
                      <textarea
                        className="form-control"
                        rows="2"
                        value={formData.renewalTerms}
                        onChange={(e) => setFormData({...formData, renewalTerms: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      rows="2"
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={handleCloseDialog}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    {editingContract ? 'Update Contract' : 'Create Contract'}
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}

      {/* Contract Details Modal */}
      {selectedContract && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">📋 Contract Details</h5>
                <button type="button" className="btn-close" onClick={handleCloseModal}></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6>Contract Information</h6>
                    <p><strong>Number:</strong> {selectedContract.contractNumber}</p>
                    <p><strong>Title:</strong> {selectedContract.title}</p>
                    <p><strong>Type:</strong> <span className="badge bg-secondary">{selectedContract.contractType}</span></p>
                    <p><strong>Status:</strong> <span className={getStatusBadgeClass(selectedContract.status)}>{selectedContract.status}</span></p>
                  </div>
                  <div className="col-md-6">
                    <h6>Supplier & Dates</h6>
                    <p><strong>Supplier:</strong> {selectedContract.supplierName}</p>
                    <p><strong>Start Date:</strong> {selectedContract.startDate}</p>
                    <p><strong>End Date:</strong> {selectedContract.endDate}</p>
                    <p><strong>Total Value:</strong> <strong>${selectedContract.totalValue.toLocaleString()}</strong></p>
                  </div>
                </div>
                <hr />
                <div className="row">
                  <div className="col-12">
                    <h6>Description</h6>
                    <p>{selectedContract.description || 'No description provided'}</p>
                  </div>
                </div>
                {selectedContract.terms && (
                  <>
                    <hr />
                    <div className="row">
                      <div className="col-12">
                        <h6>Terms</h6>
                        <p>{selectedContract.terms}</p>
                      </div>
                    </div>
                  </>
                )}
                {selectedContract.renewalTerms && (
                  <>
                    <hr />
                    <div className="row">
                      <div className="col-12">
                        <h6>Renewal Terms</h6>
                        <p>{selectedContract.renewalTerms}</p>
                      </div>
                    </div>
                  </>
                )}
                {selectedContract.notes && (
                  <>
                    <hr />
                    <div className="row">
                      <div className="col-12">
                        <h6>Notes</h6>
                        <p>{selectedContract.notes}</p>
                      </div>
                    </div>
                  </>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                  Close
                </button>
                <button 
                  type="button" 
                  className="btn btn-warning" 
                  onClick={() => {
                    handleCloseModal();
                    handleOpenDialog(selectedContract);
                  }}
                >
                  Edit Contract
                </button>
              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  );
};

export default Contracts;
