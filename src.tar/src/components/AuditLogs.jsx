import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const AuditLogs = () => {
  const { t } = useTranslation();
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState('all');
  const [filterEntity, setFilterEntity] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedLog, setSelectedLog] = useState(null);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [logsPerPage] = useState(10);

  const actions = [
    'LOGIN', 'LOGOUT', 'CREATE', 'UPDATE', 'DELETE', 'VIEW'
  ];

  const entities = [
    'User', 'Supplier', 'Order', 'Payment', 'Inventory', 'Contract'
  ];

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  const fetchAuditLogs = async () => {
    try {
      setLoading(true);
      // Mock data since we don't have audit endpoint yet
      const mockAuditLogs = [
        {
          id: 1,
          timestamp: '2024-01-15T10:30:00Z',
          action: 'LOGIN',
          entityType: 'User',
          entityName: 'john.doe@company.com',
          userName: 'John Doe',
          ipAddress: '192.168.1.100',
          statusCode: 200,
          details: 'User logged in successfully',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        {
          id: 2,
          timestamp: '2024-01-15T10:25:00Z',
          action: 'CREATE',
          entityType: 'Supplier',
          entityName: 'ABC Supplies Ltd',
          userName: 'Jane Smith',
          ipAddress: '192.168.1.101',
          statusCode: 201,
          details: 'New supplier created',
          userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        },
        {
          id: 3,
          timestamp: '2024-01-15T10:20:00Z',
          action: 'UPDATE',
          entityType: 'Order',
          entityName: 'ORD-2024-001',
          userName: 'Mike Johnson',
          ipAddress: '192.168.1.102',
          statusCode: 200,
          details: 'Order status updated to shipped',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      ];
      setAuditLogs(mockAuditLogs);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      displayAlert('Error fetching audit logs', 'danger');
    } finally {
      setLoading(false);
    }
  };



  const getActionIcon = (action) => {
    switch (action) {
      case 'LOGIN': return '🔐';
      case 'LOGOUT': return '🚪';
      case 'CREATE': return '➕';
      case 'UPDATE': return '✏️';
      case 'DELETE': return '🗑️';
      case 'VIEW': return '👁️';
      default: return '🔒';
    }
  };

  const getActionBadgeClass = (action) => {
    switch (action) {
      case 'LOGIN': return 'badge bg-success';
      case 'LOGOUT': return 'badge bg-warning';
      case 'CREATE': return 'badge bg-info';
      case 'UPDATE': return 'badge bg-primary';
      case 'DELETE': return 'badge bg-danger';
      case 'VIEW': return 'badge bg-secondary';
      default: return 'badge bg-secondary';
    }
  };

  const getStatusBadgeClass = (statusCode) => {
    if (statusCode >= 200 && statusCode < 300) return 'badge bg-success';
    if (statusCode >= 400 && statusCode < 500) return 'badge bg-warning';
    if (statusCode >= 500) return 'badge bg-danger';
    return 'badge bg-secondary';
  };

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.entityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.action.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAction = filterAction === 'all' || log.action === filterAction;
    const matchesEntity = filterEntity === 'all' || log.entityType === filterEntity;
    const matchesDateRange = (!startDate || log.timestamp >= startDate) && 
                            (!endDate || log.timestamp <= endDate);
    
    return matchesSearch && matchesAction && matchesEntity && matchesDateRange;
  });

  // Pagination
  const indexOfLastLog = currentPage * logsPerPage;
  const indexOfFirstLog = indexOfLastLog - logsPerPage;
  const currentLogs = filteredLogs.slice(indexOfFirstLog, indexOfLastLog);
  const totalPages = Math.ceil(filteredLogs.length / logsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleViewDetails = (log) => {
    setSelectedLog(log);
  };

  const handleCloseModal = () => {
    setSelectedLog(null);
  };

  const exportLogs = () => {
    displayAlert('Export functionality coming soon!', 'info');
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="audit-logs-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">🔒 Audit Logs</h2>
              <p className="text-muted mb-0">Monitor system activities and user actions</p>
            </div>
            <div className="btn-group">
              <button className="btn btn-outline-secondary" onClick={fetchAuditLogs}>
                <span className="me-2">🔄</span>Refresh
              </button>
              <button className="btn btn-primary" onClick={exportLogs}>
                <span className="me-2">📥</span>Export
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Logs</h6>
                  <h4 className="mb-0">{auditLogs.length}</h4>
                </div>
                <div className="fs-1">📊</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Today</h6>
                  <h4 className="mb-0">{auditLogs.filter(log => 
                    new Date(log.timestamp).toDateString() === new Date().toDateString()
                  ).length}</h4>
                </div>
                <div className="fs-1">📅</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-info text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Active Users</h6>
                  <h4 className="mb-0">{new Set(auditLogs.map(log => log.userName)).size}</h4>
                </div>
                <div className="fs-1">👥</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-warning text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Failed Actions</h6>
                  <h4 className="mb-0">{auditLogs.filter(log => log.statusCode >= 400).length}</h4>
                </div>
                <div className="fs-1">⚠️</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🔍 Filters</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-3 mb-3">
              <label className="form-label">Search</label>
              <div className="input-group">
                <span className="input-group-text">🔍</span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Action</label>
              <select
                className="form-select"
                value={filterAction}
                onChange={(e) => setFilterAction(e.target.value)}
              >
                <option value="all">All Actions</option>
                {actions.map(action => (
                  <option key={action} value={action}>{action}</option>
                ))}
              </select>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Entity</label>
              <select
                className="form-select"
                value={filterEntity}
                onChange={(e) => setFilterEntity(e.target.value)}
              >
                <option value="all">All Entities</option>
                {entities.map(entity => (
                  <option key={entity} value={entity}>{entity}</option>
                ))}
              </select>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Start Date</label>
              <input
                type="date"
                className="form-control"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">End Date</label>
              <input
                type="date"
                className="form-control"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Audit Logs</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Date & Time</th>
                  <th>Action</th>
                  <th>Entity</th>
                  <th>Entity Name</th>
                  <th>User</th>
                  <th>IP Address</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentLogs.map((log) => (
                  <tr key={log.id}>
                    <td>
                      <small className="text-muted">
                        {new Date(log.timestamp).toLocaleString()}
                      </small>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <span className="me-2">{getActionIcon(log.action)}</span>
                        <span className={getActionBadgeClass(log.action)}>
                          {log.action}
                        </span>
                      </div>
                    </td>
                    <td>{log.entityType}</td>
                    <td>
                      <strong>{log.entityName}</strong>
                    </td>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" 
                             style={{ width: '24px', height: '24px', fontSize: '12px' }}>
                          👤
                        </div>
                        {log.userName}
                      </div>
                    </td>
                    <td>
                      <code className="small">{log.ipAddress}</code>
                    </td>
                    <td>
                      <span className={getStatusBadgeClass(log.statusCode)}>
                        {log.statusCode}
                      </span>
                    </td>
                    <td>
                      <button 
                        className="btn btn-outline-primary btn-sm"
                        onClick={() => handleViewDetails(log)}
                        title="View Details"
                      >
                        👁️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Empty State */}
      {filteredLogs.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No audit logs found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Details Modal */}
      {selectedLog && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">📋 Audit Log Details</h5>
                <button type="button" className="btn-close" onClick={handleCloseModal}></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6>Action Details</h6>
                    <p><strong>Action:</strong> <span className={getActionBadgeClass(selectedLog.action)}>{selectedLog.action}</span></p>
                    <p><strong>Entity Type:</strong> {selectedLog.entityType}</p>
                    <p><strong>Entity Name:</strong> {selectedLog.entityName}</p>
                    <p><strong>Status Code:</strong> <span className={getStatusBadgeClass(selectedLog.statusCode)}>{selectedLog.statusCode}</span></p>
                  </div>
                  <div className="col-md-6">
                    <h6>User Information</h6>
                    <p><strong>User:</strong> {selectedLog.userName}</p>
                    <p><strong>IP Address:</strong> <code>{selectedLog.ipAddress}</code></p>
                    <p><strong>Timestamp:</strong> {new Date(selectedLog.timestamp).toLocaleString()}</p>
                    <p><strong>User Agent:</strong> <small className="text-muted">{selectedLog.userAgent}</small></p>
                  </div>
                </div>
                <hr />
                <div className="row">
                  <div className="col-12">
                    <h6>Details</h6>
                    <p>{selectedLog.details}</p>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                  Close
                </button>
              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </div>
      )}
    </div>
  );
};

export default AuditLogs;
