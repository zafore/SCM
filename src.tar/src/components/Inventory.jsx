import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const Inventory = () => {
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    try {
      setLoading(true);
      // Mock data since we don't have inventory endpoint yet
      const mockInventory = [
        {
          id: 1,
          itemName: 'Office Chair',
          sku: 'CHAIR-001',
          category: 'Furniture',
          currentStock: 25,
          minStock: 10,
          maxStock: 100,
          unitPrice: 150.00,
          status: 'In Stock',
          lastUpdated: '2024-01-15',
          description: 'Ergonomic office chair with adjustable height',
          supplier: 'Office Supplies Co.',
          location: 'Warehouse A'
        },
        {
          id: 2,
          itemName: 'Laptop Computer',
          sku: 'LAPTOP-002',
          category: 'Electronics',
          currentStock: 5,
          minStock: 10,
          maxStock: 50,
          unitPrice: 1200.00,
          status: 'Low Stock',
          lastUpdated: '2024-01-14',
          description: '15-inch business laptop with Intel i7 processor',
          supplier: 'Tech Solutions Inc.',
          location: 'Warehouse B'
        },
        {
          id: 3,
          itemName: 'Desk Lamp',
          sku: 'LAMP-003',
          category: 'Furniture',
          currentStock: 15,
          minStock: 8,
          maxStock: 75,
          unitPrice: 45.00,
          status: 'In Stock',
          lastUpdated: '2024-01-13',
          description: 'LED desk lamp with adjustable brightness',
          supplier: 'Lighting Pro',
          location: 'Warehouse A'
        },
        {
          id: 4,
          itemName: 'Wireless Mouse',
          sku: 'MOUSE-004',
          category: 'Electronics',
          currentStock: 30,
          minStock: 15,
          maxStock: 100,
          unitPrice: 25.00,
          status: 'In Stock',
          lastUpdated: '2024-01-12',
          description: 'Ergonomic wireless mouse with precision tracking',
          supplier: 'Tech Solutions Inc.',
          location: 'Warehouse B'
        }
      ];
      setInventory(mockInventory);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      displayAlert('Error fetching inventory', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  const getStockStatus = (current, min) => {
    if (current <= min) return { status: 'Low Stock', color: 'danger' };
    if (current <= min * 1.5) return { status: 'Medium Stock', color: 'warning' };
    return { status: 'In Stock', color: 'success' };
  };

  const getStockStatusBadge = (current, min) => {
    const stockStatus = getStockStatus(current, min);
    return `badge bg-${stockStatus.color}`;
  };

  const getStockLevelClass = (current, min) => {
    if (current <= min) return 'text-danger';
    if (current <= min * 1.5) return 'text-warning';
    return 'text-success';
  };

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || getStockStatus(item.currentStock, item.minStock).status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredInventory.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredInventory.length / itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const exportInventory = () => {
    displayAlert('Export functionality coming soon!', 'info');
  };

  const addItem = () => {
    displayAlert('Add inventory feature coming soon!', 'info');
  };

  const categories = [...new Set(inventory.map(item => item.category))];
  const statuses = ['In Stock', 'Medium Stock', 'Low Stock'];

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="inventory-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">📦 Inventory Management</h2>
              <p className="text-muted mb-0">Track and manage your inventory items</p>
            </div>
            <div className="btn-group">
              <button className="btn btn-outline-secondary" onClick={fetchInventory}>
                <span className="me-2">🔄</span>Refresh
              </button>
              <button className="btn btn-primary" onClick={addItem}>
                <span className="me-2">➕</span>Add Item
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Items</h6>
                  <h4 className="mb-0">{inventory.length}</h4>
                </div>
                <div className="fs-1">📦</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">In Stock</h6>
                  <h4 className="mb-0">{inventory.filter(item => 
                    getStockStatus(item.currentStock, item.minStock).status === 'In Stock'
                  ).length}</h4>
                </div>
                <div className="fs-1">✅</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-warning text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Low Stock</h6>
                  <h4 className="mb-0">{inventory.filter(item => 
                    getStockStatus(item.currentStock, item.minStock).status === 'Low Stock'
                  ).length}</h4>
                </div>
                <div className="fs-1">⚠️</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-info text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Value</h6>
                  <h4 className="mb-0">${inventory.reduce((sum, item) => 
                    sum + (item.currentStock * item.unitPrice), 0
                  ).toLocaleString()}</h4>
                </div>
                <div className="fs-1">💰</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🔍 Filters</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4 mb-3">
              <label className="form-label">Search</label>
              <div className="input-group">
                <span className="input-group-text">🔍</span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Category</label>
              <select
                className="form-select"
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
              >
                <option value="all">All Categories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3 mb-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Statuses</option>
                {statuses.map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </div>
            <div className="col-md-2 mb-3">
              <label className="form-label">Actions</label>
              <div className="d-grid">
                <button className="btn btn-outline-secondary" onClick={exportInventory}>
                  <span className="me-2">📥</span>Export
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Inventory Items</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Item</th>
                  <th>Category</th>
                  <th>Current Stock</th>
                  <th>Min Stock</th>
                  <th>Max Stock</th>
                  <th>Unit Price</th>
                  <th>Status</th>
                  <th>Last Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div className="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                             style={{ width: '40px', height: '40px', fontSize: '16px' }}>
                          📦
                        </div>
                        <div>
                          <strong>{item.itemName}</strong>
                          <br />
                          <small className="text-muted">{item.sku}</small>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge bg-secondary">{item.category}</span>
                    </td>
                    <td>
                      <span className={getStockLevelClass(item.currentStock, item.minStock)}>
                        <strong>{item.currentStock}</strong>
                      </span>
                    </td>
                    <td>{item.minStock}</td>
                    <td>{item.maxStock}</td>
                    <td>
                      <strong>${item.unitPrice.toFixed(2)}</strong>
                    </td>
                    <td>
                      <span className={getStockStatusBadge(item.currentStock, item.minStock)}>
                        {getStockStatus(item.currentStock, item.minStock).status}
                      </span>
                    </td>
                    <td>
                      <small className="text-muted">{item.lastUpdated}</small>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button className="btn btn-outline-primary btn-sm" title="View Details">
                          👁️
                        </button>
                        <button className="btn btn-outline-warning btn-sm" title="Edit">
                          ✏️
                        </button>
                        <button className="btn btn-outline-danger btn-sm" title="Delete">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <li key={page} className={`page-item ${currentPage === page ? 'active' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button 
                  className="page-link" 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Empty State */}
      {filteredInventory.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No inventory items found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Stock Level Indicators */}
      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h6 className="mb-0">📊 Stock Level Indicators</h6>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-4 text-center">
                  <div className="text-success">
                    <div className="fs-1">✅</div>
                    <h6>In Stock</h6>
                    <p className="text-muted">Items with sufficient stock levels</p>
                  </div>
                </div>
                <div className="col-md-4 text-center">
                  <div className="text-warning">
                    <div className="fs-1">⚠️</div>
                    <h6>Medium Stock</h6>
                    <p className="text-muted">Items approaching minimum stock levels</p>
                  </div>
                </div>
                <div className="col-md-4 text-center">
                  <div className="text-danger">
                    <div className="fs-1">🚨</div>
                    <h6>Low Stock</h6>
                    <p className="text-muted">Items below minimum stock levels</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
