import React from "react";

const AdminPage = () => <h2>Admin Page - Only for admins</h2>;

export default AdminPage;