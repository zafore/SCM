import React from 'react';

const DemoStatus = () => {
  return (
    <div className="demo-status" style={{
      position: 'fixed',
      top: '10px',
      right: '10px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      padding: '8px 12px',
      borderRadius: '20px',
      fontSize: '12px',
      fontWeight: '500',
      zIndex: 9999,
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      border: '1px solid rgba(255,255,255,0.2)'
    }}>
      <i className="bi bi-info-circle me-1"></i>
      Demo Mode
    </div>
  );
};

export default DemoStatus;
