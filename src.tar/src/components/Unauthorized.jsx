import React from 'react';
import { useNavigate } from 'react-router-dom';

const Unauthorized = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1);
  };

  const handleGoHome = () => {
    navigate('/dashboard');
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <div className="text-center mt-5">
            <div className="card shadow">
              <div className="card-body p-5">
                <div className="fs-1 text-danger mb-3">🚫</div>
                
                <h1 className="h3 text-danger mb-3">
                  Access Denied
                </h1>
                
                <h6 className="text-muted mb-3">
                  You don't have permission to access this page.
                </h6>
                
                <p className="text-muted mb-4">
                  Please contact your administrator if you believe this is an error.
                </p>
                
                <div className="d-grid gap-2">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={handleGoBack}
                  >
                    <span className="me-2">⬅️</span>Go Back
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={handleGoHome}
                  >
                    <span className="me-2">🏠</span>Go to Dashboard
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Unauthorized;