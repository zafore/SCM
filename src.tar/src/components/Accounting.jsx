import React, { useState, useEffect } from 'react';
import api from '../services/api.js';
import { ENDPOINTS } from '../config.js';

const Accounting = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');

  const displayAlert = (message, type = 'success') => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 5000);
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      // Mock data since we don't have accounting endpoint yet
      const mockTransactions = [
        {
          id: 1,
          transactionNumber: 'TXN-2024-001',
          date: '2024-01-15',
          description: 'Payment to ABC Supplies Ltd',
          type: 'Expense',
          amount: 5000.00,
          account: 'Accounts Payable',
          reference: 'PAY-2024-001',
          status: 'Posted'
        },
        {
          id: 2,
          transactionNumber: 'TXN-2024-002',
          date: '2024-01-16',
          description: 'Revenue from Product Sales',
          type: 'Income',
          amount: 15000.00,
          account: 'Accounts Receivable',
          reference: 'SALE-2024-001',
          status: 'Posted'
        }
      ];
      setTransactions(mockTransactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      displayAlert('Error fetching transactions', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.transactionNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || transaction.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Posted': return 'badge bg-success';
      case 'Pending': return 'badge bg-warning';
      case 'Draft': return 'badge bg-secondary';
      default: return 'badge bg-secondary';
    }
  };

  const getTypeBadgeClass = (type) => {
    return type === 'Income' ? 'badge bg-success' : 'badge bg-danger';
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="accounting-container">
      {/* Header Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h2 className="mb-1">📊 Accounting & Transactions</h2>
              <p className="text-muted mb-0">Manage financial transactions and accounting records</p>
            </div>
            <button className="btn btn-primary">
              <span className="me-2">➕</span>New Transaction
            </button>
          </div>
        </div>
      </div>

      {/* Alert */}
      {showAlert && (
        <div className={`alert alert-${alertType} alert-dismissible fade show`} role="alert">
          {alertMessage}
          <button type="button" className="btn-close" onClick={() => setShowAlert(false)}></button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-3 mb-3">
          <div className="card bg-primary text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Income</h6>
                  <h4 className="mb-0">$15,000</h4>
                </div>
                <div className="fs-1">💰</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-danger text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Total Expenses</h6>
                  <h4 className="mb-0">$5,000</h4>
                </div>
                <div className="fs-1">💸</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-success text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Net Profit</h6>
                  <h4 className="mb-0">$10,000</h4>
                </div>
                <div className="fs-1">📈</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="card bg-info text-white h-100">
            <div className="card-body">
              <div className="d-flex justify-content-between">
                <div>
                  <h6 className="card-title">Pending</h6>
                  <h4 className="mb-0">$2,500</h4>
                </div>
                <div className="fs-1">⏳</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="row mb-4">
        <div className="col-md-6 mb-3">
          <div className="input-group">
            <span className="input-group-text">🔍</span>
            <input
              type="text"
              className="form-control"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <select
            className="form-select"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="all">All Types</option>
            <option value="Income">Income</option>
            <option value="Expense">Expense</option>
          </select>
        </div>
        <div className="col-md-3 mb-3">
          <button className="btn btn-outline-secondary w-100">
            <span className="me-2">📊</span>Export
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">📋 Recent Transactions</h5>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>Transaction #</th>
                  <th>Date</th>
                  <th>Description</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Account</th>
                  <th>Reference</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id}>
                    <td>
                      <strong>{transaction.transactionNumber}</strong>
                    </td>
                    <td>{transaction.date}</td>
                    <td>{transaction.description}</td>
                    <td>
                      <span className={getTypeBadgeClass(transaction.type)}>
                        {transaction.type}
                      </span>
                    </td>
                    <td>
                      <span className={transaction.type === 'Income' ? 'text-success' : 'text-danger'}>
                        <strong>${transaction.amount.toLocaleString()}</strong>
                      </span>
                    </td>
                    <td>{transaction.account}</td>
                    <td>{transaction.reference}</td>
                    <td>
                      <span className={getStatusBadgeClass(transaction.status)}>
                        {transaction.status}
                      </span>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button className="btn btn-outline-primary btn-sm" title="Edit">
                          ✏️
                        </button>
                        <button className="btn btn-outline-danger btn-sm" title="Delete">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Empty State */}
      {filteredTransactions.length === 0 && (
        <div className="text-center py-5">
          <div className="fs-1 mb-3">📭</div>
          <h5>No transactions found</h5>
          <p className="text-muted">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
};

export default Accounting;
