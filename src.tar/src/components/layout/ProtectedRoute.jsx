import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { isAuthenticated, getCurrentUser, hasAnyRole } from '../../utils/authUtils.js';

const ProtectedRoute = ({ children, allowedRoles = [] }) => {
  const location = useLocation();
  const user = getCurrentUser();
  const authenticated = isAuthenticated();

  // Show loading while checking authentication
  if (!user && authenticated === null) {
    return (
      <div className="d-flex flex-column justify-content-center align-items-center min-vh-100">
        <div className="spinner-border text-primary" style={{width: '3rem', height: '3rem'}} role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        <h6 className="mt-3 text-muted">Loading...</h6>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!authenticated || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check role-based access
  if (allowedRoles.length > 0 && !hasAnyRole(allowedRoles)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
};

export default ProtectedRoute;
