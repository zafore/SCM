import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getCurrentUser, getUserRole, logout } from '../../utils/authUtils.js';
import LanguageSwitcher from '../LanguageSwitcher.jsx';
import './MainLayout.css';

const MainLayout = ({ children }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('');
  const [notifications, setNotifications] = useState([]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setUserRole(getUserRole());
    }
    
    // Simulate notifications
    setNotifications([
      { id: 1, message: 'New order received', time: '2 min ago', type: 'info' },
      { id: 2, message: 'Payment confirmed', time: '15 min ago', type: 'success' },
      { id: 3, message: 'Low stock alert', time: '1 hour ago', type: 'warning' },
      { id: 4, message: 'System backup completed', time: '2 hours ago', type: 'info' }
    ]);
  }, []);

  const menuItems = [
    { text: t('common.dashboard'), path: '/dashboard', icon: '📊', permission: 'dashboard:view' },
    { text: t('common.suppliers'), path: '/suppliers', icon: '🏢', permission: 'suppliers:view' },
    { text: t('common.orders'), path: '/orders', icon: '📦', permission: 'orders:view' },
    { text: t('common.inventory'), path: '/inventory', icon: '🏪', permission: 'inventory:view' },
    { text: t('common.payments'), path: '/payments', icon: '💳', permission: 'payments:view' },
    { text: t('common.accounting'), path: '/accounting', icon: '📊', permission: 'accounting:view' },
    { text: t('common.contracts'), path: '/contracts', icon: '📋', permission: 'contracts:view' },
    { text: t('common.userManagement'), path: '/user-management', icon: '👥', permission: 'users:view' },
    { text: t('common.auditLogs'), path: '/audit-logs', icon: '🔍', permission: 'audit:view' },
    { text: t('common.lookupManagement'), path: '/lookup-management', icon: '⚙️', permission: 'lookup:view' },
    { text: 'Auth Test', path: '/auth-test', icon: '🔐', permission: 'auth:test' }
  ];

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleLogout = () => {
    logout();
  };

  const handleSettings = () => {
    // Handle settings navigation
    console.log('Navigate to settings');
    setProfileMenuOpen(false);
  };

  const handleNotificationClick = (notification) => {
    console.log('Notification clicked:', notification);
    // Handle notification click
  };

  const filteredMenuItems = menuItems.filter(item => {
    // In a real app, check actual permissions
    return true;
  });

  const drawer = (
    <div className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
      {/* Enhanced Logo/Brand Section */}
      <div className="sidebar-brand">
        <div className="brand-logo">
          <span className="brand-icon">🏢</span>
          {!sidebarCollapsed && (
            <>
              <h3 className="brand-title">SCM Admin</h3>
              <p className="brand-subtitle">Supply Chain Management</p>
            </>
          )}
        </div>
        <button 
          className="sidebar-toggle"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <i className={`bi bi-chevron-${sidebarCollapsed ? 'right' : 'left'}`}></i>
        </button>
      </div>

      {/* Enhanced User Info Section */}
      <div className="sidebar-user">
        <div className="user-avatar">
          {user?.name?.charAt(0)?.toUpperCase() || 'U'}
        </div>
        {!sidebarCollapsed && (
          <div className="user-info">
            <h6 className="user-name">{user?.name || 'User'}</h6>
            <p className="user-role">{userRole}</p>
            <div className="user-status">
              <span className="status-dot active"></span>
              <small>Online</small>
            </div>
          </div>
        )}
      </div>

      {/* Enhanced Navigation Menu */}
      <nav className="sidebar-nav">
        {filteredMenuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <a
              key={item.text}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                navigate(item.path);
                if (window.innerWidth < 768) {
                  setMobileOpen(false);
                }
              }}
              className={`nav-item ${isActive ? 'active' : ''}`}
              title={sidebarCollapsed ? item.text : ''}
            >
              <span className="nav-icon">{item.icon}</span>
              {!sidebarCollapsed && <span className="nav-text">{item.text}</span>}
              {isActive && <div className="nav-indicator"></div>}
            </a>
          );
        })}
      </nav>

      {/* Enhanced Sidebar Footer */}
      {!sidebarCollapsed && (
        <div className="sidebar-footer">
          <div className="system-status">
            <div className="status-item">
              <span className="status-dot normal"></span>
              <small>System: Operational</small>
            </div>
            <div className="status-item">
              <span className="status-dot normal"></span>
              <small>Uptime: 99.97%</small>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="layout-container">
      {/* Enhanced Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div className="sidebar-overlay" onClick={handleDrawerToggle}>
          <div className="overlay-content">
            <div className="spinner-border text-light" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Sidebar */}
      <aside className={`sidebar-container ${mobileOpen ? 'open' : ''} ${sidebarCollapsed ? 'collapsed' : ''}`}>
        {drawer}
      </aside>

      {/* Enhanced Main Content Area */}
      <main className={`main-content ${sidebarCollapsed ? 'expanded' : ''}`}>
        {/* Enhanced Top Navigation Bar */}
        <header className="top-navbar">
          <div className="navbar-content">
            <div className="navbar-left">
              <button
                className="menu-toggle d-md-none"
                onClick={handleDrawerToggle}
              >
                <span className="hamburger"></span>
              </button>
              <button
                className="sidebar-toggle-desktop d-none d-md-block"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              >
                <i className={`bi bi-chevron-${sidebarCollapsed ? 'right' : 'left'}`}></i>
              </button>
              <h4 className="page-title">
                {filteredMenuItems.find(item => item.path === location.pathname)?.text || t('common.dashboard')}
              </h4>
            </div>

            <div className="navbar-actions">
              {/* Enhanced Language Switcher */}
              <div className="navbar-item">
                <LanguageSwitcher />
              </div>

              {/* Enhanced Notifications */}
              <div className="navbar-item notifications">
                <button 
                  className="btn btn-link position-relative notification-btn"
                  onClick={() => setNotifications([])}
                >
                  <i className="bi bi-bell"></i>
                  {notifications.length > 0 && (
                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge">
                      {notifications.length}
                    </span>
                  )}
                </button>
                
                {/* Enhanced Notifications Dropdown */}
                {notifications.length > 0 && (
                  <div className="notifications-dropdown">
                    <div className="notifications-header">
                      <h6>Notifications</h6>
                      <button 
                        className="btn btn-sm btn-link text-muted"
                        onClick={() => setNotifications([])}
                      >
                        Mark all as read
                      </button>
                    </div>
                    <div className="notifications-list">
                      {notifications.map(notification => (
                        <div 
                          key={notification.id} 
                          className={`notification-item ${notification.type}`}
                          onClick={() => handleNotificationClick(notification)}
                        >
                          <div className="notification-icon">
                            <i className={`bi bi-${notification.type === 'success' ? 'check-circle' : 
                                           notification.type === 'warning' ? 'exclamation-triangle' : 
                                           'info-circle'}`}></i>
                          </div>
                          <div className="notification-content">
                            <p className="notification-message">{notification.message}</p>
                            <small className="notification-time">{notification.time}</small>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Enhanced Profile Dropdown */}
              <div className="navbar-item profile-dropdown">
                <button
                  className="btn btn-link profile-btn"
                  onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                >
                  <div className="profile-avatar">
                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <span className="profile-name d-none d-lg-inline">{user?.name || 'User'}</span>
                  <i className="bi bi-chevron-down"></i>
                </button>
                
                {profileMenuOpen && (
                  <div className="profile-menu">
                    <div className="profile-header">
                      <div className="profile-avatar-large">
                        {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                      </div>
                      <div className="profile-info">
                        <h6 className="profile-name">{user?.name || 'User'}</h6>
                        <p className="profile-role">{userRole}</p>
                        <p className="profile-username">{user?.nameid || user?.name || 'admin'}</p>
                      </div>
                    </div>
                    <hr />
                    <button className="profile-menu-item" onClick={handleSettings}>
                      <span className="menu-icon"><i className="bi bi-gear"></i></span>
                      Settings
                    </button>
                    <button className="profile-menu-item">
                      <span className="menu-icon"><i className="bi bi-person"></i></span>
                      Profile
                    </button>
                    <button className="profile-menu-item">
                      <span className="menu-icon"><i className="bi bi-question-circle"></i></span>
                      Help & Support
                    </button>
                    <hr />
                    <button className="profile-menu-item text-danger" onClick={handleLogout}>
                      <span className="menu-icon"><i className="bi bi-box-arrow-right"></i></span>
                      {t('common.logout')}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Enhanced Page Content */}
        <div className="page-content">
          <div className="content-wrapper">
            {children}
          </div>
        </div>

        {/* Enhanced Footer */}
        <footer className="main-footer">
          <div className="footer-content">
            <div className="footer-left">
              <small className="text-muted">
                © 2024 SCM Admin Portal. All rights reserved.
              </small>
            </div>
            <div className="footer-right">
              <small className="text-muted">
                <span className="me-3">
                  <i className="bi bi-shield-check me-1"></i>
                  Secure Connection
                </span>
                <span className="me-3">
                  <i className="bi bi-clock me-1"></i>
                  Last updated: {new Date().toLocaleTimeString()}
                </span>
                <span>
                  <i className="bi bi-activity me-1"></i>
                  v2.1.0
                </span>
              </small>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default MainLayout;
