import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AuthService from '../services/AuthServices.js';
import "../styles/design-system.css";
import "../styles/login.css";

const Login = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [shake, setShake] = useState(false);

  useEffect(() => {
    // Add entrance animation
    const timer = setTimeout(() => {
      document.querySelector('.login-card')?.classList.add('show');
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (error) {
      setError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.username || !formData.password) {
      setError('Please fill in all fields');
      setShake(true);
      setTimeout(() => setShake(false), 500);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await AuthService.login(formData.username, formData.password);
      if (result.success) {
        // Show success message if it's demo mode
        if (result.message && result.message.includes('Demo')) {
          console.log('🎉 Demo login successful');
        }
        navigate('/dashboard');
      } else {
        setError(result.message || 'Invalid credentials');
        setShake(true);
        setTimeout(() => setShake(false), 500);
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Login failed. Please check your backend connection.');
      setShake(true);
      setTimeout(() => setShake(false), 500);
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setFormData({
      username: 'admin@test.com',
      password: 'Admin123!'
    });
    
    setLoading(true);
    try {
      const result = await AuthService.login('admin@test.com', 'Admin123!');
      if (result.success) {
        navigate('/dashboard');
      } else {
        setError(result.message || 'Demo login failed');
      }
    } catch (err) {
      setError('Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      {/* Enhanced Animated Background */}
      <div className="login-background">
        <div className="shape shape-1"></div>
        <div className="shape shape-2"></div>
        <div className="shape shape-3"></div>
        <div className="shape shape-4"></div>
        <div className="background-overlay"></div>
      </div>

      {/* Enhanced Login Card */}
      <div className={`login-card card-enhanced scale-in ${shake ? 'shake' : ''}`}>
        <div className="card-body p-5">
          {/* Enhanced Logo Section */}
          <div className="logo-container text-center mb-4">
            <div className="logo-icon mb-3">
              <span className="display-1">🏢</span>
            </div>
            <h1 className="h2 fw-bold text-primary mb-2">
              SCM Admin Portal
            </h1>
            <p className="text-muted mb-0">
              Supply Chain Management System
            </p>
            <div className="logo-shine"></div>
          </div>

          {/* Enhanced Welcome Message */}
          <div className="text-center mb-4">
            <h2 className="h4 fw-semibold text-dark mb-2">
              Welcome Back! 👋
            </h2>
            <p className="text-muted">
              Sign in to access your dashboard
            </p>
          </div>

          {/* Enhanced Error Alert */}
          {error && (
            <div className={`alert alert-${shake ? 'danger' : 'danger'}-enhanced mb-4 ${shake ? 'shake' : ''}`}>
              <div className="d-flex align-items-center">
                <i className="bi bi-exclamation-triangle-fill me-2"></i>
                <span>{error}</span>
              </div>
            </div>
          )}

          {/* Enhanced Login Form */}
          <form onSubmit={handleSubmit} className="login-form">
            {/* Username Field */}
            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-dark mb-2">
                <i className="bi bi-person me-2 text-primary"></i>
                Username
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <i className="bi bi-person-fill text-muted"></i>
                </span>
                <input
                  type="text"
                  className="form-control-enhanced border-start-0"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  placeholder="Enter your username"
                  autoComplete="username"
                  required
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-dark mb-2">
                <i className="bi bi-lock me-2 text-primary"></i>
                Password
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <i className="bi bi-shield-lock text-muted"></i>
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  className="form-control-enhanced border-start-0"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  required
                />
                <button
                  type="button"
                  className="btn btn-outline-secondary border-start-0"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ borderLeft: 'none' }}
                >
                  <i className={`bi ${showPassword ? 'bi-eye-slash' : 'bi-eye'}`}></i>
                </button>
              </div>
            </div>

            {/* Enhanced Remember Me & Forgot Password */}
            <div className="d-flex justify-content-between align-items-center mb-4">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="rememberMe"
                />
                <label className="form-check-label text-muted" htmlFor="rememberMe">
                  Remember me
                </label>
              </div>
              <a href="#" className="text-primary text-decoration-none fw-medium">
                Forgot password?
              </a>
            </div>

            {/* Enhanced Login Button */}
            <button
              type="submit"
              className="btn btn-primary-enhanced btn-lg w-100 mb-3"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                  Signing in...
                </>
              ) : (
                <>
                  <i className="bi bi-box-arrow-in-right me-2"></i>
                  Sign In
                </>
              )}
            </button>

            {/* Enhanced Demo Login Button */}
       
          </form>

         
          <div className="text-center">
            <hr className="my-4" />
            <p className="text-muted small mb-2">
              <i className="bi bi-shield-check me-2"></i>
              Secure login powered by enterprise-grade security
            </p>
            <p className="text-muted small mb-0">
              Need help? <a href="#" className="text-primary">Contact support</a>
            </p>
          </div>
        </div>
      </div>

      {/* Enhanced Floating Elements */}
      <div className="floating-elements">
        <div className="floating-icon floating-icon-1">📊</div>
        <div className="floating-icon floating-icon-2">🚀</div>
        <div className="floating-icon floating-icon-3">💡</div>
        <div className="floating-icon floating-icon-4">🎯</div>
      </div>
    </div>
  );
};

export default Login;